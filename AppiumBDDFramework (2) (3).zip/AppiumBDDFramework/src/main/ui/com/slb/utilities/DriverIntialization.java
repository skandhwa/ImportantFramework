package com.slb.utilities;

import java.io.IOException;
import java.net.URI;
import java.net.URL;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;

import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
//import org.testng.annotations.Optional;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import io.appium.java_client.AppiumDriver;
//import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.Activity;
import io.appium.java_client.android.AndroidDriver;
//import io.appium.java_client.android.AndroidKeyCode;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.remote.SupportsContextSwitching;
import io.appium.java_client.service.local.AppiumDriverLocalService;
import io.appium.java_client.touch.WaitOptions;
import io.appium.java_client.touch.offset.PointOption;

public class DriverIntialization extends CommonFunctions {
	
	
	//	public static AppiumDriver driver;
	// public AndroidDriver<MobileElement> driver;
	public static  WebDriver driver1;
	public ExtentReports extent = ExtentManager.getInstance();
	public Logger logger = Logger.getLogger(DriverIntialization.class);
	public ExtentTest test;
	AppiumDriverLocalService appiumService;
	String appiumServiceUrl;

	
	

	public static String parameterName;

	// *********************Start AppiumServer ************************************
	public void startAppiumServer() {
		try {
			
			logger.info("Starting the Appium Server");
			appiumService = AppiumDriverLocalService.buildDefaultService();
			appiumService.start();
			appiumServiceUrl = appiumService.getUrl().toString();
			logger.info("Appium Service Address : - " + appiumServiceUrl);
			logger.info("The Appium Server is started");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public String startASession()
    {
        String apiUrl = "https://api-dev.headspin.io/v0/sessions";
        //String apiKey = "0ecb95c0d59c40e99566140ddffc2e56";
        String apiKey = "349b0bc2a8d749708cbddc88223b6d16";
        
        //String deviceAddress = "00008110-001E091E0EC0401E@dev-in-blr-0-proxy-0-mac.headspin.io";  //For iPhone13
        //String deviceAddress = "00008030-0001504E2E6B402E@dev-in-blr-0-proxy-23-mac.headspin.io";	//For iPhone11
        String deviceAddress = "00008120-000229192613C01E@dev-in-blr-0-proxy-17-mac.headspin.io";	//For iPhone14
        String jsonPayload = "{\"session_type\": \"capture\",\"device_address\": \"" + deviceAddress + "\"}";
        HttpClient httpClient = HttpClient.newHttpClient();

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(apiUrl))
                .header("Content-Type", "application/json")
                .header("Authorization", "Bearer " + apiKey)
                .POST(HttpRequest.BodyPublishers.ofString(jsonPayload))
                .build();
        System.out.println("Build completed");
        try
        {
            HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
            System.out.println("Response Body: " + response.body());
            String sessionId = response.body().split("\"session_id\": \"")[1].split("\"")[0];
            System.out.println("Session ID: " + sessionId);
            return sessionId;
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        return apiUrl;
    }
	
    public void stopASession(String sessionID)
    {
        String apiUrl = "https://api-dev.headspin.io/v0/sessions/";
        String apiKey = "349b0bc2a8d749708cbddc88223b6d16";
        String sessionId = sessionID;
        String jsonPayload = "{\"active\": false}";
        HttpClient httpClient = HttpClient.newHttpClient();


        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(apiUrl + sessionId))
                .header("Content-Type", "application/json")
                .header("Authorization", "Bearer " + apiKey)
                .method("PATCH", HttpRequest.BodyPublishers.ofString(jsonPayload))
                .build();

        try
        {
            HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
            System.out.println("Response Body: " + response.body());
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }
	// *********************Browser Driver Setup
	// ************************************
	
	
	public void driverSetup(@Optional String strDeviceName, @Optional String strAppName, @Optional String browserName) {
		if (browserName.contains("Chrome") || browserName.contains("Safari") || browserName.contains("FireFox")
				|| browserName.contains("internet explorer")) {
			onBrowser(browserName);

		} else {
			onMobile(strDeviceName, strAppName);

		}

	}

	private void onMobile(String strDeviceName, String strAppName) {
		try {
			String strDeviceType = null;

			if (strDeviceName.contains("Perfecto")) {
//				strDeviceType = "Perfecto" + DeviceMap.valueOf(strDeviceName).getPlatformName();
				strDeviceType = "Android";
			} else if (strDeviceName.contains("Simulator")) {
				strDeviceType = "Simulator" + DeviceMap.valueOf(strDeviceName).getPlatformName();
			} else if (strDeviceName.contains("Emulator")) {
				strDeviceType = "Emulator" + DeviceMap.valueOf(strDeviceName).getPlatformName();
			}
			else if(strDeviceName.contains("PCloudy"))
			{
				strDeviceType = "PCloudy" + DeviceMap.valueOf(strDeviceName).getPlatformName();	
			}

			else {
				strDeviceType = DeviceMap.valueOf(strDeviceName).getPlatformName();
			}

			// object for Desired Capabilities
			DesiredCapabilities capabilities = new DesiredCapabilities();

			// The kind of mobile device or emulator to use
//			capabilities.setCapability("deviceName", DeviceMap.valueOf(strDeviceName).getDeviceName());
//			capabilities.setCapability("platformName", DeviceMap.valueOf(strDeviceName).getPlatformName());
			
			capabilities.setCapability("noReset", true);

			logger.info("Inside the DriverSetup() method with browserType as " + strDeviceType);

			if (strDeviceType.equalsIgnoreCase("Android") || strDeviceType.equalsIgnoreCase("iOS")
					|| strDeviceType.contains("Simulator") || strDeviceType.contains("Emulator")) {
				logger.info("Starting the Appium server since the device type is " + strDeviceType + "(local device)");
				if (strDeviceType.equalsIgnoreCase("Android")) {
//					capabilities.setCapability("appPackage", AppMap.valueOf(strAppName).getAppPackage());
////					capabilities.setCapability("userProfile", 12);
//					capabilities.setCapability("appActivity", AppMap.valueOf(strAppName).getAppActivity());
//					capabilities.setCapability("automationName", "UiAutomator1");
					
					capabilities.setCapability("appPackage", AppMap.valueOf(strAppName).getAppPackage());
//					capabilities.setCapability("userProfile", 12);
					capabilities.setCapability("appActivity", AppMap.valueOf(strAppName).getAppActivity());
					capabilities.setCapability("appium:app", AppMap.valueOf(strAppName).getFilePath());
					capabilities.setCapability("appium:automationName", "UiAutomator2");
				} else if (strDeviceType.equalsIgnoreCase("SimulatoriOS")) {
					capabilities.setCapability("automationName", "XCUITest");
					// capabilities.setCapability("app", AppMap.valueOf(strAppName).getFilePath());
					capabilities.setCapability("bundleId", AppMap.valueOf(strAppName).getBundleId());
				} else if (strDeviceType.equalsIgnoreCase("EmulatorAndroid")) {
					capabilities.setCapability("automationName", "UiAutomator2");
					capabilities.setCapability("avd", "Nexus_6_API_27");
					capabilities.setCapability("appPackage", AppMap.valueOf(strAppName).getAppPackage());
					capabilities.setCapability("appActivity", AppMap.valueOf(strAppName).getAppActivity());
					
				} else {
					capabilities.setCapability("automationName", "XCUITest");
					capabilities.setCapability("udid", DeviceMap.valueOf(strDeviceName).getUdid());
					capabilities.setCapability("bundleId", AppMap.valueOf(strAppName).getBundleId());
					capabilities.setCapability("headspin:controlLock", DeviceMap.valueOf(strDeviceName).getcontrolLock());
					//capabilities.setCapability("headspin:appiumVersion", DeviceMap.valueOf(strDeviceName).getAppiumVersion());
					capabilities.setCapability("newCommandTimeout",300);
					//capabilities.setCapability("headspin:capture.video", "true");		//For Without Network
					capabilities.setCapability("headspin:capture", "true");				//For With Network
				}

				if (strDeviceType.equalsIgnoreCase("Android")) {
//					driver = new AppiumDriver<WebElement>(new URL("http://127.0.0.1:4723/wd/hub"), capabilities);
//					logger.info("Android Driver is created");
					
					driver = new AndroidDriver(new URI("http://127.0.0.1:4723").toURL(),capabilities);
					logger.info("Android Driver is created");
				} else if (strDeviceType.equalsIgnoreCase("EmulatorAndroid")) {
//					driver = new AppiumDriver<WebElement>(new URL("http://0.0.0.0:4723/wd/hub"), capabilities);
//					driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
					
					driver = new AndroidDriver(new URL("http://0.0.0.0:4723/wd/hub"), capabilities);
					driver = new AndroidDriver(new URI("http://127.0.0.1:4723").toURL(),capabilities);
					driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
					logger.info("Android Driver is created");
				}

				else if (strDeviceType.equalsIgnoreCase("iOS")) {
					 //driver = new IOSDriver(new URL("http://127.0.0.1:4723/wd/hub"),capabilities);
					//driver = new IOSDriver(new URI("http://127.0.0.1:4723").toURL(),capabilities);
					//For iPhone13
					//String appiumURL = "https://dev-in-blr-0.headspin.io:7014/v0/349b0bc2a8d749708cbddc88223b6d16/wd/hub";
					//For iPhone11
					String appiumURL = "https://dev-in-blr-0.headspin.io:7031/v0/349b0bc2a8d749708cbddc88223b6d16/wd/hub";
					//For iPhone13(2)
					//String appiumURL = "https://dev-in-blr-0.headspin.io:7025/v0/349b0bc2a8d749708cbddc88223b6d16/wd/hub";
					//For iPhone14
					//String appiumURL = "https://dev-in-blr-0.headspin.io:7025/v0/349b0bc2a8d749708cbddc88223b6d16/wd/hub";
					URL url = new URL(appiumURL);
			        driver = new IOSDriver(url, capabilities);
			        System.out.println("Orignal: "+driver.getSessionId());
					logger.info("iOS Driver is created");
//					capabilities.setCapability("appPackage", "com.pcloudy.appiumdemo");
//					capabilities.setCapability("appActivity", "com.ba.mobile.LaunchActivity");
				} else {
					 driver = new IOSDriver(new URL("http://127.0.0.1:4723/wd/hub"),
					 capabilities);
					logger.info("iOS Driver is created");
				}
			}

			else if (strDeviceType.equalsIgnoreCase("PerfectoAndroid")
					|| strDeviceType.equalsIgnoreCase("PerfectoiOS")) {

				String host = globalVariables.Perfecto_Host_Name;
				// capabilities.setCapability("user", globalVariables.Perfecto_Username);
				// capabilities.setCapability("password", globalVariables.Perfecto_Password);

				capabilities.setCapability("securityToken",
						"eyJhbGciOiJSUzI1NiIsInR5cCIgOiAiSldUIiwia2lkIiA6ICJnc3g3VldzZzNUa0g2cTRNTnIwMVk0ajFnOW5oLWN0MENpbm9JcnkwZGdRIn0.eyJqdGkiOiI5YTc5NTllYy0wN2Q2LTQ2YzItOWY1NS0zYjM1YjE4MmM0Y2YiLCJleHAiOjAsIm5iZiI6MCwiaWF0IjoxNTY4MDExMTYwLCJpc3MiOiJodHRwczovL2F1dGgucGVyZmVjdG9tb2JpbGUuY29tL2F1dGgvcmVhbG1zL3NsYi1wZXJmZWN0b21vYmlsZS1jb20iLCJhdWQiOiJvZmZsaW5lLXRva2VuLWdlbmVyYXRvciIsInN1YiI6IjQ4NDkwZWI1LTUwYWItNDA4ZS1hNTBmLTAxNDUyMDg1YjY3ZiIsInR5cCI6Ik9mZmxpbmUiLCJhenAiOiJvZmZsaW5lLXRva2VuLWdlbmVyYXRvciIsIm5vbmNlIjoiZjMzNTUwZDgtMjQyZC00ODNhLTkxNzYtYmY2MTBmYjQ2ZTAxIiwiYXV0aF90aW1lIjowLCJzZXNzaW9uX3N0YXRlIjoiMWQ5YjE1YTYtOTFiOS00M2JhLThjZGQtYmE3MWE2Y2E4MzVjIiwicmVhbG1fYWNjZXNzIjp7InJvbGVzIjpbIm9mZmxpbmVfYWNjZXNzIiwidW1hX2F1dGhvcml6YXRpb24iXX0sInJlc291cmNlX2FjY2VzcyI6eyJhY2NvdW50Ijp7InJvbGVzIjpbIm1hbmFnZS1hY2NvdW50IiwibWFuYWdlLWFjY291bnQtbGlua3MiLCJ2aWV3LXByb2ZpbGUiXX19fQ.i4ZfPSuK2odiCMLkx3zHf-2e-ra34jsjE8k60Y4dh77bfdoOOBpy1MuqCNamMRJawjPFVdBaz89CvfNopfUAntmGi1dc_QZexxUWR_XqjHoC32qH9wJzY0PRW_02HcToWvxUgZeZu9U-mGI81Mf-LpsZThqPpZXuNeUPTQoLJ2Hi1ecD8PadyIJwHy7UBL5IazSkj9YMQ3pOSR-8YxtwjBRKImvSiEDblMQpMFAFtcQhSA-6edX1SLIYrL_rPO4K9YZl6j29eFZmUgjFKdihmZZzIYz_FNlRIDkXY2NIVHAwttTIMH6n9eekpCD9UdPizkTttRsUgVHVqYwX1t64hA");

				// Call this method if you want the script to share the devices with the
				// Perfecto Lab plugin.
				// PerfectoLabUtils.setExecutionIdCapability(capabilities, host);
				PerfectoLabUtils.setExecutionIdCapability(capabilities, host);
				String url = "http://" + host + "/nexperience/perfectomobile/wd/hub";

				if (strDeviceType.equalsIgnoreCase("PerfectoAndroid")) {
					driver = new AndroidDriver(new URL(url), capabilities);
					logger.info("Perfecto Android Driver is created");
				} else if (strDeviceType.equalsIgnoreCase("PerfectoIOS")) {
					// driver = new IOSDriver(new URL(url), capabilities);
					logger.info("Perfecto iOS Driver is created");
				}
			} else if (strDeviceType.equalsIgnoreCase("PCloudyAndroid")
					|| strDeviceType.equalsIgnoreCase("PCloudyiOS")) {
				//DesiredCapabilities capabilities = new DesiredCapabilities();
				capabilities.setCapability("pCloudy_Username", "valkari@slb.com");
				capabilities.setCapability("pCloudy_ApiKey", "pkqdjfh56zrc5wgznc5wpd3f");
				capabilities.setCapability("pCloudy_DurationInMinutes", 10);
				capabilities.setCapability("newCommandTimeout", 600);
				capabilities.setCapability("launchTimeout", 90000);
				capabilities.setCapability("pCloudy_DeviceFullName", "APPLE_iPadmini6thGen_iOS_16.1.1_a997b");
				capabilities.setCapability("platformVersion", "16.1.1");
				capabilities.setCapability("platformName", "ios");
				capabilities.setCapability("acceptAlerts", true);
				capabilities.setCapability("automationName", "XCUITest");
				capabilities.setCapability("bundleId", "com.sap.mobile.apps.assetmanager.release");
				capabilities.setCapability("pCloudy_WildNet", "false");
				capabilities.setCapability("pCloudy_EnableVideo", "true");
				capabilities.setCapability("pCloudy_EnablePerformanceData", "true");
				capabilities.setCapability("pCloudy_EnableDeviceLogs", "true");
				capabilities.setCapability("appiumVersion", "1.22.0");
				//IOSDriver<WebElement> driver = new IOSDriver<WebElement>(new URL("https://slb-west.pcloudy.com/appiumcloud/wd/hub"), capabilities);
				//capabilities.setCapability("pCloudy_DevicePasscode", "147369");
				// capabilities.setCapability("pCloudy_DeviceFullName", AppMap.valueOf(deviceName).getFilePath());
			
//			
//	
//				capabilities.setCapability("appPackage", "com.pcloudy.appiumdemo");
//				capabilities.setCapability("appActivity", "com.ba.mobile.LaunchActivity");

				String url = "https://slb-west.pcloudy.com/appiumcloud/wd/hub";

				if (strDeviceType.equalsIgnoreCase("PCloudyAndroid")) {
					capabilities.setCapability("appPackage", AppMap.valueOf(strAppName).getAppPackage());
					capabilities.setCapability("appActivity", AppMap.valueOf(strAppName).getAppActivity());
					capabilities.setCapability("automationName", "uiautomator2");
					driver = new AndroidDriver(new URL(url), capabilities);
					logger.info("pcloudy Android Driver is created");
				}
				
				if (strDeviceType.equalsIgnoreCase("PCloudyiOS")) {
					capabilities.setCapability("automationName", "XCUITest");
					capabilities.setCapability("bundleId", AppMap.valueOf(strAppName).getBundleId());
					//driver = new IOSDriver<WebElement>(new URL(url), capabilities);
					driver = new IOSDriver(new URL(url), capabilities);
					logger.info("pcloudy iOS Driver is created");
				}
			}

			driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);

			// To unlock the device based on the device type
			// deviceUnlock(strDeviceType);

		} catch (Exception e) {
			logger.info("Inside exception - Unable to create Driver object");
			logger.info(e.getMessage());
		}
	}

	public void onBrowser(String browserName) {
		if (browserName.contains("Chrome")) {

			System.setProperty("webdriver.chrome.driver", globalVariables.CHROME_DRIVER_PATH);
			driver1 = new ChromeDriver();
		} else if (browserName.contains("FireFox")) {

			System.setProperty("webdriver.gecko.driver", globalVariables.FF_DRIVER_PATH);
			driver1 = new FirefoxDriver();

		} else if (browserName.contains("internet explorer")) {
			System.setProperty("webdriver.ie.driver", globalVariables.IE_DRIVER_PATH);
			driver1 = new InternetExplorerDriver();
		}
	}

	public void launchURL(String url) {
		System.out.println("launching URL");
		driver1.get(url);
	}
	

	public void launchApp(String strAppName, String strDeviceName, String browserName, String URL)
			throws InterruptedException {

		if (browserName.contains("Chrome") || browserName.contains("safari") || browserName.contains("FireFox")
				|| browserName.contains("internet explorer")) {
			launchURL(URL);

			parameterName = "Browser";

		} else {

			logger.info("Inside the LaunchApp() method");

			String strDeviceType = null;
			if (strDeviceName.contains("Perfecto")) {
				strDeviceType = "Perfecto" + DeviceMap.valueOf(strDeviceName).getPlatformName();
			} else {
				strDeviceType = DeviceMap.valueOf(strDeviceName).getPlatformName();
			}

//		strAppName = AppMap.valueOf(strAppName).getAppName();

			if (strDeviceType.equalsIgnoreCase("PerfectoAndroid") || strDeviceType.equalsIgnoreCase("PerfectoiOS")) {

				logger.info("INSIDE IFFFFFF");

				Map<String, Object> appMapParam = new HashMap<>();
				appMapParam.put("name", strAppName);

				//driver.executeScript("mobile:application:close", appMapParam);

				Thread.sleep(5000);

				logger.info("Opening the application - " + appMapParam);
				//driver.executeScript("mobile:application:open", appMapParam);

				Thread.sleep(5000);

			}

			//else if (strDeviceType.equalsIgnoreCase("Android") || strDeviceType.equalsIgnoreCase("iOS"))
			else if (strDeviceType.equalsIgnoreCase("iOS") || strDeviceType.equalsIgnoreCase("Android")){
				logger.info("Doing nothing as app is already launched");
			}

			// enterSecureCode(strDeviceType);
			parameterName = "Mobile";
			// acceptMobileIronMessage();
		}

	}

//	public void enterSecureCode(String strDeviceType) throws InterruptedException {
//
//		int count = 0;
//
//		String strPasscode = globalVariables.MI_PassCode;
//
//		if (strDeviceType.equalsIgnoreCase("PerfectoAndroid") || strDeviceType.equalsIgnoreCase("Android")) {
//
//			count = driver.findElements(By.id("com.forgepond.locksmith:id/mi_zone_password_title")).size();
//
//			if (count > 0) {
//
//				logger.info("Entering MI passcode");
//
//				driver.findElement(By.id("com.forgepond.locksmith:id/mi_zone_password_title")).sendKeys(strPasscode);
//
//				((AndroidDriver) driver).pressKeyCode(AndroidKeyCode.ENTER);
//
//			}
//		} else if (strDeviceType.equalsIgnoreCase("PerfectoiOS") || strDeviceType.equalsIgnoreCase("iOS")) {
//			driver.context("NATIVE_APP");
//			count = driver.findElements(By.xpath("//*[@label='AppConnect Passcode Field']")).size();
//			System.out.println(count);
//
//			if (count > 0) {
//
//				logger.info("Entering MI passcode");
//
//				driver.findElement(By.xpath("//*[@label='AppConnect Passcode Field']")).sendKeys(strPasscode);
//
//				driver.findElement(By.xpath("//*[@label='Done']")).click();
//			}
//		}
//
//		if (count == 0) {
//
//			logger.info("Not entering the MI passcode as it is not asked for");
//
//		}
//	}

	public void acceptMobileIronMessage() {

		if (driver.findElement(By.xpath("//*[@value=\\\"�eJourney� wants to open �MobileIron�\\\"]"))
				.isDisplayed()) {
			driver.findElement(By.xpath("//*[@label=\"Open\"]")).click();
		}
	}

//	public void deviceUnlock(String strDeviceType) throws InterruptedException {
//
//		logger.info("Inside the deviceUnlock() method");
//
//		if (strDeviceType.equalsIgnoreCase("PerfectoAndroid") || strDeviceType.equalsIgnoreCase("Android")) {
//
//			Dimension size = driver.manage().window().getSize();
//
//			int startx = size.width / 2;
//			int starty = (int) (size.height * 0.98);
//
//			((SupportsContextSwitching) driver).context("NATIVE_APP");
//
//			boolean deviceLocked = ((AndroidDriver) driver).isDeviceLocked();
//			logger.info("Device Locked? : " + deviceLocked);
//
//			if (deviceLocked) {
//
//				Thread.sleep(2000);
//
//				logger.info("Clicking on the Power/Home button to unlock the device");
//				((AndroidDriver) driver).pressKeyCode(AndroidKeyCode.KEYCODE_POWER);
//
//				Thread.sleep(2000);
//
//				logger.info("Swiping up to bring up the keypad to enter the lock code");
//
//				TouchAction touchAction = new TouchAction(driver);
//
//				touchAction.press(PointOption.point(startx, starty))
//						.waitAction(WaitOptions.waitOptions(Duration.ofMillis(200)))
//						.moveTo(PointOption.point(startx, 50)).release();
//				driver.performTouchAction(touchAction);
//
//				driver.context("NATIVE_APP");
//
//				String strPasscode = globalVariables.Device_PassCode;
//				char chrNumKey;
//
//				for (int i = 0; i < strPasscode.length(); i++) {
//					chrNumKey = strPasscode.charAt(i);
//					driver.findElement(By.xpath("//*[@text='" + chrNumKey + "']")).click();
//				}
//
//				driver.findElement(By.xpath("//*[@content-desc='Enter']")).click();
//
//				Thread.sleep(3000);
//
//			} else {
//
//				logger.info("The device is already in open (unlocked) state");
//			}
//
//		} else if (strDeviceType.equalsIgnoreCase("PerfectoIOS") || strDeviceType.equalsIgnoreCase("iOS")) {
//
//			// Device unlock code to be entered for PerfectoIOS and iOS
//			logger.info("Device is already unlocked for : " + strDeviceType);
//		}
//
//	}
	
//	@Parameters({ "deviceName", "appName", "browserName" })
//	@BeforeSuite
//	public void Initialization(@Optional("iPhone5S_Perfecto") String strDeviceName,
//			@Optional("ECLAIMS") String strAppName, @Optional String browserName)
//			throws InterruptedException, IOException {
//
//		DOMConfigurator.configure("log-setup.xml");
//		logger.info("Inside the Initialization() @BeforeSuite ");
//
//		driverSetup(strDeviceName, strAppName, browserName);
//		launchApp(strAppName, strDeviceName, "", "");
//		System.out.println("completed");
//		
//		// Waiting for the launching screen or dashboard to display
//		// TO DO - to be later replaced by Wait statements
//		// Thread.sleep(45000);
//
//	}


}
