package com.slb.utilities;

import java.io.File;

public enum AppMap{
//	EJ("eJourney","com.slb.ejourney.droid.test","md5ed3aa3e263db8c3fb1c9778c971bd782.MainActivity","com.slbdev.ejourney.ios",new File("/Users/prajakta/Downloads/eJourney.iOS.app")), 
//	HSE("HSE Report","forgepond.com.slbdev.HSEMobile.Droid","md508338ca740eb1e51f0c344d0f1cd8c6f.SplashActivityFPAlias","com.slb.HSEMobile.iOS",new File("")), 
//	LCR("Loadchart","forgepond.com.slb.LoadChart.Droid","md5ab5c040caa3102566385f1bdd15766fa.SplashActivityFPAlias","com.slbdev.loadchart.ios",new File("")), 
//	TTM("Toolbox","forgepond.com.slbdev.ttm","md513e4f1dbb75c2acd39860dc16fcd2d2f.SplashActivityFPAlias","com.slb.ttm",new File("")),
//	LDAP("Ldap Search","forgepond.com.slbdev.ldapsearch.Droid","md5183ddeb7070b279f4f754ba5735cb08a.SplashActivityFPAlias","com.slbdev.ldapsearch.ios",new File("")), 
//	APProve("APProve","forgepond.com.slbdev.Approve.Droid","md56b51284f1db273ed467bf6561f2b1b89.SplashActivityFPAlias","com.slbdev.Approve.iOS",new File("")),
//	BD("BD","forgepond.com.slb.briefdebrief","md5ae2da25f4800836f35c1f2ad523164e9.SplashActivity","",new File("")),
//	GR("GR","forgepond.com.slb.readytogr","md5fd1fd838995615ca184abd244bdf2af1.SplashActivity","",new File("")),
//	FDP("FDP Mobile","forgepond.com.slb.fdpdashboard","md50eab0c2dfd540d950a116d6a935dffd7.SplashActivity","",new File("")),
//	RFID("RFIDPrototype","","","com.slbdev.rfidprototype.ios",new File("")),
//	OA("OneApprove","","","com.slbdev.oneapprove",new File("")),
//	SAFARI("","","","",new File("")),
//	TAPP("Isin Olsun","com.isinolsun.app","com.isinolsun.app.activities.SplashActivity","",new File("")),
//	ECLAIMS("eClaims Mobile","com.slb.eclaimsmobile.droid.test","md59d4c1ce86f752fef28fe6dacd8f35b7d.SplashActivity","com.slbdev.eclaimsmobile.ios",new File("")),
//	Camera("Camera","com.android.camera","com.android.camera.Camera"," ",new File("")),
//	Calculator("Calculator","com.android.calculator2","com.android.calculator2.Calculator"," ",new File("")),
//	PCloudy_App("TestmunkDemo_Resigned1632462491.ipa"," "," ","com.pcloudy.TestmunkDemo",new File("")),
//	PCloudy_App2("pCloudyAppiumDemo.apk","com.pcloudy.appiumdemo","com.ba.mobile.LaunchActivity","",new File("")),
//	Chrome("Chrome","com.android.chrome","org.chromium.android_webview.devui.MainActivity"," ",new File(" ")),
//	API("API","com.example.android.apis","com.example.android.apis.ApiDemos"," ",new File(" ")),
//	
	//Emulator_test("APIDemo","com.google.android.gm",".ConversationListActivityGmail","",new File(""));
	//Emulator_test("ApiDemos-debug","","","","C://Users//VAlkari//Desktop//Mobile Automation Testing//ApiDemos-debug 2.apk");
	CMMS_App("","","","com.sap.mobile.apps.assetmanager.release");
	//App("","","","com.apple.Preferences");
	
	private String appName;
	private String appPackage;
	private String appActivity;
	private String bundleId;
	//private File appFilePath;
	private String appFilePath;

	public String getAppName() {
		return this.appName;
	}

	public String getAppPackage() {
		return this.appPackage;
	}

	public String getAppActivity() {
		return this.appActivity;
	}
	
	public String getBundleId() {
		return this.bundleId;
	}

	//AppMap(String appName, String appPackage, String appActivity, String bundleId,String appFilePath){
	AppMap(String appName, String appPackage, String appActivity, String bundleId){
		this.appName = appName;
		this.appPackage = appPackage;
		this.appActivity = appActivity;
		this.bundleId = bundleId;
		this.appFilePath = appFilePath;
	}

	public String getFilePath() {
		// TODO Auto-generated method stub
		return this.appFilePath;
		
	}

}
