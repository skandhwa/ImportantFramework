package com.slb.utilities;

public enum DeviceMap{
	/*
	SamsungS7_Perfecto("Android","9885E6384C3859544B","",""), 
	iPhone7_Perfecto("iOS","441C601D3BBC51D85C9A8BEFA0DD2D4381B40D7F","",""), 
	iPhone5S_Perfecto("iOS","839EDC867B43E33785CD19C2F856930F005C8BAB","",""), 
	iPhone6SPlus_Perfecto("iOS","1CBE7D06959D88488E5AA5FAFA0377A98420A8F9","",""),
	Nexus6_Perfecto("Android","ZY2233LBB6","",""), 
	SamsungS5_Perfecto("Android","EBD39BB3","",""), 
	HTCOneM8_Perfecto("Android","HT45VSF00957","",""),
	SamsungNote5_Perfecto("Android","8575433631415446","",""),
	SamsungS7_BLORE("Android","ce11160bd1a7291c02","",""),
	SamsungNote5_BLORE("Android","843153434a4b3145","",""),
	SamsungS5_BLORE("Android","3208d66e16dd7199","",""),	
	GooglePixel_BLORE("Android","FA6A40301483","",""),	
	iPhone7_BLORE("iOS","","cc1cf5d9a00926fec5a562bcec7670676b658ea5",""),
	iPhone8_BLORE("iOS","","e879510351563af070051e25925e75dba8e6ae92",""),
	SamsungS8_BLORE("Android","ce10171ac1d4351305","",""),
	iPhone6SPlus_BLORE("iOS","","d70ed43c91961ec57cdbf54cf7cb6ff0e6d07c51",""),
	iPhone6Black_BLORE("iOS","","735d921ff77ef386eb35bd0f72e99cdfe2a494bb",""),
	iPhone6Gold_BLORE("iOS","","78873486c38313e53889fb919ed77596d9e367ff",""),
	SamsungS7_PUNE("Android","ce11160bd1a7291c02","",""),
	GooglePixel_PUNE("Android","FA6AB0306102","",""),
	MotoX_PUNE("Android","TA0830531R","",""),
	iPhone6_PUNE("iOS","","5ff30561891e1cbba0048f5329430f2d9308bcc4",""),
	iPhoneX_PUNE("iOS","","cbd7c873e1c7a10eb6063675f669b44e64bb9ad6",""),
	Pixel3("Android","8CTX1T42R","",""),
	iPhone7_Simulator("iOS","iPhone 7","",""),
	//iPhone("iOS","iPhone","d74f02944edf9bf21184962e7edc20fccb00e000",""),
	//iPhone("iOS","SLB-Indiv-LQWQ4D94D3","00008101-0005288E0E9B001E",""),
	PixelPie_Emulator("Android","emulator-5554","emulator-5554",""),
	S9_Emulator("Android","emulator-5554","emulator-5554",""),
	N6_Emulator("Android","emulator-5554","emulator-5554",""),
	Redmi("Android","c2d642389907"," ",""),
	PCloudy_SAMSUNG_GalaxyS8("Android","SAMSUNG_GalaxyS8_Android_9.0.0_a84cb","",""),
	PCloudy_iPhone("iOS","APPLE_iPhone8plus_iOS_11.3.1_61643", " ","11.3."),
	Pcloudy_Ipadmini("iOS","APPLE_iPad9.7_iOS_13.3.0_2f675"," ",""),
	Oppo_android("Android","497bcedd"," ",""),
	TestDevice("Android","emulator-5554","",""),
	//Emualator_Device("Android","emulator-5554","emulator-5554","");*/
	Emualator_Device("Android","VeenaPhone","","", "", ""),
	iPhone("iOS","iPhone 13","00008110-001E091E0EC0401E","","true","1.22.3"),
	iPhone2("iOS","iPhone 13","00008110-0016695E3684401E","","true","1.22.3"),
	iPhone11("iOS","iPhone 11","00008030-0001504E2E6B402E","","true","2.0.0"),
	PCloudy("ios","APPLE_iPhone14_iOS_16.0.3_6dffa","","16.0.3","","1.21.0"),
	iPhone14_H("iOS","iPhone 14 Pro Max","00008120-000229192613C01E","","true","2.0.0");
	
	
	public String platformName;
	private String deviceName;
	private String udid;
	private String platformVersion;
	private String controlLock;
	private String appiumVersion;

	public String getPlatformName() {
		return this.platformName;
	}

	public String getDeviceName() {
		return this.deviceName;
	}
	
	public String getUdid() {
		return this.udid;
	}
	
	public String getPlatformVersion() {
		return this.platformVersion;
	}
	public String getcontrolLock() {
		return this.controlLock;
	}
	
	public String getAppiumVersion() {
		return this.appiumVersion;
	}
	

	 DeviceMap(String platformName, String deviceName, String udid, String platformVersion,String controlLock,String appiumVersion ) {
		this.platformName = platformName;
		this.deviceName = deviceName;
		this.udid = udid;
		this.platformVersion = platformVersion;
		this.controlLock = controlLock;
		this.appiumVersion = appiumVersion;
	}

}

