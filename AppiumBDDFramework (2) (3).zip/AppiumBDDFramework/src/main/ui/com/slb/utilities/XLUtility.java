package com.slb.utilities;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class XLUtility {
	
	private static XSSFWorkbook excelWBook;
	private static XSSFSheet excelWSheet;
    private static XSSFCell cell;
    private static XSSFRow row;

	public static Map<String, String> readTestDataFromXLS(String fileName) throws IOException
	{
		InputStream ExcelFileToRead = new FileInputStream(fileName);
		HSSFWorkbook wb = new HSSFWorkbook(ExcelFileToRead);

		HSSFSheet sheet=wb.getSheet("TestData");
		HSSFRow row; 
		HSSFCell cell;

		Iterator rows = sheet.rowIterator();
		
		Map<String, String> testDataMap = new HashMap<String, String>();
		String parameter = null;
		String value = null;
		
		while (rows.hasNext())
		{
			row=(HSSFRow) rows.next();
			Iterator cells = row.cellIterator();
			
			int count = 0;
			
			while (cells.hasNext())
			{
				cell=(HSSFCell) cells.next();
				
				if (count == 0) {
					parameter = cell.getStringCellValue();
				}else if (count == 1) {
					value = cell.getStringCellValue();
					testDataMap.put(parameter,value);
				}
				count = count + 1;
			}	
		}
		return testDataMap;
	
	}
	
	
	public static Map<String, String> readTestDataFromXLSX(String fileName) throws IOException
	{
		InputStream ExcelFileToRead = new FileInputStream(fileName);
		XSSFWorkbook  wb = new XSSFWorkbook(ExcelFileToRead);
		
		//XSSFSheet sheet = wb.getSheetAt(0);
		XSSFSheet sheet = wb.getSheet("TestData");
		
		XSSFRow row; 
		XSSFCell cell;

		Iterator rows = sheet.rowIterator();
		
		Map<String, String> testDataMap = new HashMap<String, String>();
		String parameter = null;
		String value = null;
		
		DataFormatter formatter = new DataFormatter();

		while (rows.hasNext())
		{
			row=(XSSFRow) rows.next();
			Iterator cells = row.cellIterator();
			
			int count = 0;
			
			while (cells.hasNext())
			{
				cell=(XSSFCell) cells.next();
		
				if (count == 0) {
					parameter = cell.getStringCellValue();
				}else if (count == 1) {
					value = formatter.formatCellValue(cell);
					testDataMap.put(parameter,value);
				}
				count = count + 1;	
			}
		}
		return testDataMap;
	
	}
	
		
		
		
		 public static String readExcel(String filePath,String fileName,String sheetName,int rownum,int setdata) throws IOException{

			    //Create an object of File class to open xlsx file

			    File file =    new File(filePath+"\\"+fileName);

			    //Create an object of FileInputStream class to read excel file

			    FileInputStream inputStream = new FileInputStream(file);

			    Workbook guru99Workbook = null;

			    //Find the file extension by splitting file name in substring  and getting only extension name

			    String fileExtensionName = fileName.substring(fileName.indexOf("."));

			    //Check condition if the file is xlsx file

			    if(fileExtensionName.equals(".xlsx")){

			    //If it is xlsx file then create object of XSSFWorkbook class

			    guru99Workbook = new XSSFWorkbook(inputStream);

			    }
			    
			    else if(fileExtensionName.equals(".xls")){

			        //If it is xls file then create object of HSSFWorkbook class

			        guru99Workbook = new HSSFWorkbook(inputStream);

			    }
			    org.apache.poi.ss.usermodel.Sheet guru99Sheet = guru99Workbook.getSheet(sheetName);

			    //Find number of rows in excel file

			    int rowCount = ((org.apache.poi.ss.usermodel.Sheet) guru99Sheet).getLastRowNum()-((org.apache.poi.ss.usermodel.Sheet) guru99Sheet).getFirstRowNum();

			    //Create a loop over all the rows of excel file to read it

			    

			        Row row = ((org.apache.poi.ss.usermodel.Sheet) guru99Sheet).getRow(rownum);

			        //Create a loop to print cell values in a row

			       

			            //Print Excel data in console
			      
			       
		return	    row.getCell(setdata).toString();
			        
			        
			        //    System.out.print(row.getCell(0).getStringCellValue());
			            
			            

			        

			        

			    } 

		// It creates FileInputStream and set excel file and excel sheet to excelWBook and excelWSheet variables. 
		 //Read excel data
		 public static void readExcelXLS(String fileName) throws IOException
			{
				InputStream ExcelFileToRead = new FileInputStream(fileName);
				excelWBook = new XSSFWorkbook(ExcelFileToRead);
				
				//XSSFSheet sheet = wb.getSheetAt(0);
				 excelWSheet = excelWBook.getSheet("TestData");
				

			}
			
		 //This method return the row count of open excel sheet
		 public static int getRowCount() throws Exception {
			
		        try {
		        	
				   int lastRow = excelWSheet.getLastRowNum();
				   int firstRow = excelWSheet.getFirstRowNum();
				   return lastRow-firstRow;
		        } catch (Exception e) {
		            throw (e);
		        }
		    }
		 //This method takes row number as parameter and return column count of given row
		 public static int getColCount(int RowNum) throws Exception {
				
			 
		        try {
		        	row = excelWSheet.getRow(RowNum);
				   int lastCol = row.getLastCellNum();
				   int firstCol = row.getFirstCellNum();
		            return lastCol-firstCol;
		        } catch (Exception e) {
		            throw (e);
		        }
		    }
		 
		//This method takes row number as a parameter and returns the data of given row number.
		    public static XSSFRow getRowData(int RowNum) throws Exception {
		        try {
		            row = excelWSheet.getRow(RowNum);
		            return row;
		        } catch (Exception e) {
		            throw (e);
		        }
		    }

		 
		  //We are passing row number and column number as parameters to get cell data.
		    public static String getCellData(int RowNum, int ColNum) throws Exception {
		        try {
		            cell = excelWSheet.getRow(RowNum).getCell(ColNum);
		            DataFormatter formatter = new DataFormatter();
		            String cellData = formatter.formatCellValue(cell);
		            return cellData;
		        } catch (Exception e) {
		        	  throw (e);
		        }
		    }
		    
		    //This method gets excel file, row and column number and set a value to the that cell.
		    public static void setCellData(String testDataExcelPath,int value, int RowNum, int ColNum) throws Exception {
		        try {
		            row = excelWSheet.getRow(RowNum);
		            cell = row.getCell(ColNum);
		            if (cell == null) {
		                cell = row.createCell(ColNum);
		                cell.setCellValue(value);
		            } else {
		                cell.setCellValue(value);
		            }
		           
		            FileOutputStream fileOut = new FileOutputStream(testDataExcelPath);//globalVariables.TestDataSheets_Path
		            excelWBook.write(fileOut);
		            fileOut.flush();
		            fileOut.close();
		            
		        } catch (Exception e) {
		            try {
		                throw (e);
		            } catch (IOException e1) {
		                e1.printStackTrace();
		            }
		        }
		    }
		    
		
}