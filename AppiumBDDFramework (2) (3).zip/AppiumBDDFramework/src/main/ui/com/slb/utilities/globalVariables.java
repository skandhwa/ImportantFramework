/**
 *
 */
package com.slb.utilities;

/**
 * 
 *
 */
public class globalVariables {

	// Paths
	static String projectDIR= System.getProperty("user.dir");
	public static final String CHROME_DRIVER_PATH= projectDIR + "\\resources\\drivers\\chromedriver.exe";
	public static final String FF_DRIVER_PATH=projectDIR + "\\resources\\drivers\\geckodriver.exe";
	public static final String IE_DRIVER_PATH="";
	//public static final String Extent_Report_Path=projectDIR + "\\resources\\reports\\extent_reports\\";
	public static final String Extent_Report_Path=projectDIR + "\\target\\Cucumberreports\\ExtentReport\\";
	//public static final String Extent_Screenshots_Path=projectDIR + "\\resources\\screenshots\\";
	public static final String Extent_Screenshots_Path=projectDIR + "\\target\\Cucumberreports\\ExtentReport\\";
	public static final String Extent_Config_path= projectDIR + "\\src\\test\\java\\com\\slb\\pom\\testUtils\\Reports_Config.xml";	
	public static final String TestDataSheets_Path=projectDIR + "\\resources\\testdatasheets\\";

	// Perfecto Mobile capabilities and configurations details
	
	public static final String Perfecto_Host_Name="slb.perfectomobile.com";
	public static final String Perfecto_Username= "SLal3@slb.com";
	public static final String Perfecto_Password= "Test123";
	
	public static final String MI_PassCode= "a12345";
	public static final String Device_PassCode= "12345678";
	public static final String Username= "SLal3@slb.com";
	public static final String Password= "test123";
	//public static final String Username1= "asatle@slb.com";
	//public static final String Password1= "test123";
	public static final String Username1= "aamrutkar@slb.com";
	public static final String Password1= "test123";
	
	

}
