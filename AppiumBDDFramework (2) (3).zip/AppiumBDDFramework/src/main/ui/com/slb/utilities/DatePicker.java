//package com.slb.utilities;
//
//import io.appium.java_client.AppiumDriver;
////import io.appium.java_client.MobileElement;
//import io.appium.java_client.TouchAction;
//import io.appium.java_client.pagefactory.AndroidFindBy;
//import io.appium.java_client.pagefactory.AppiumFieldDecorator;
//import io.appium.java_client.pagefactory.iOSXCUITFindBy;
//import io.appium.java_client.touch.WaitOptions;
//import io.appium.java_client.touch.offset.PointOption;
//
//import java.io.IOException;
//import java.time.Duration;
//import java.util.Arrays;
//import java.util.List;
//import java.util.concurrent.TimeUnit;
//
//import org.apache.log4j.Logger;
//import org.openqa.selenium.Dimension;
//import org.openqa.selenium.Point;
//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.WebElement;
//import org.openqa.selenium.support.PageFactory;
//
//import com.relevantcodes.extentreports.ExtentTest;
//
//
//public class DatePicker extends CommonFunctions{
//
//	//Member Variables - Mobile Elements
//
//	@AndroidFindBy(xpath="//*[@resource-id='com.slbdev.ejourney:id/txtTab']")
//	@iOSXCUITFindBy(xpath="")
//	public List<WebElement> lstDateTimeTabs;
//
//	@AndroidFindBy(xpath="//*[@resource-id='android:id/numberpicker_input']")
//	@iOSXCUITFindBy(xpath="nan")
//	public List<WebElement> lstDateTimeFields;
//
//	@AndroidFindBy(xpath="//*[@resource-id='com.slbdev.ejourney:id/btnOk']")
//	@iOSXCUITFindBy(xpath="nan")
//	public WebElement btnOKDate;
//
//
//	//Constructor and Logger
//
//	public Logger logger = Logger.getLogger(DatePicker.class);
//
//	//Member methods
//
//
//	public void selectDateFromPicker(String EnterDate) throws IOException {
//
//		List<String> arrDateTime = Arrays.asList(EnterDate.trim().split(" "));
//		String dateToBeEntered = arrDateTime.get(0).trim();
//		String monthToBeEntered = arrDateTime.get(1).trim();
//		String yearToBeEntered = arrDateTime.get(2).trim();
//		String timeToBeEntered= arrDateTime.get(3).trim();
//		String meridiemToBeEntered= arrDateTime.get(4).trim();
//		
//		List<String> arrHourMin = Arrays.asList(timeToBeEntered.trim().split(":"));
//        
//        String hourToBeEntered = arrHourMin.get(0).trim();
//        String minuteToBeEntered = arrHourMin.get(1).trim(); 
//
//		Dimension size = driver.manage().window().getSize();
//		int IncreaseY = (int) (size.height * 0.10);
//
//		clickElement(lstDateTimeTabs.get(0),"Date Tab");
//
//		Point yearPoint = ((MobileElement) lstDateTimeFields.get(2)).getCenter();
//		int yearNextX=yearPoint.getX();
//		int yearY=yearPoint.getY();
//		int yearNextY;
//
//		TouchAction touchAction = new TouchAction(driver);
//
//		String currentYear = getTextFromElement(lstDateTimeFields.get(2), "Current Year");
//		
//		int yearDiff = Integer.parseInt(yearToBeEntered) - Integer.parseInt(currentYear);
//		
//		System.out.println(yearDiff);
//		int yearCount =0;
//		if(yearDiff>0) {
//			yearNextY=yearY+IncreaseY;
//			while (yearCount < yearDiff) {
//				yearCount =yearCount + 1;
//				touchAction.tap(PointOption.point(yearNextX, yearNextY))
//				.waitAction(WaitOptions.waitOptions(Duration.ofMillis(1000))).release().perform();
//			}
//		} else if(yearDiff<0){
//			yearNextY=yearY-IncreaseY;
//			yearDiff=Math.abs(yearDiff);
//			while (yearCount < yearDiff) {
//				yearCount = yearCount + 1;
//				touchAction.tap(PointOption.point(yearNextX, yearNextY)).release().perform();
//			}
//		}
//
//		//To Check whether the first Element is month or date. According to that length of the text Date and Month Element changes
//		String text=getTextFromElement(lstDateTimeFields.get(0), "First Element in Date Fields");
//		int FirstElementLength=text.length();
//
//		WebElement lblDate=null;
//		WebElement lblMonth=null;
//
//		if(FirstElementLength==2) {
//			lblDate=lstDateTimeFields.get(0);
//			lblMonth=lstDateTimeFields.get(1);
//		}
//		else if(FirstElementLength==3) {
//			lblDate=lstDateTimeFields.get(1);
//			lblMonth=lstDateTimeFields.get(0);
//		}
//
//		Point monthPoint = ((MobileElement) lblMonth).getCenter();
//		int monthNextX=monthPoint.getX();
//		int monthY=monthPoint.getY();
//		int monthNextY=monthY+IncreaseY;
//
//
//		String currentMonth = null;
//
//		boolean isEnteredMonthDisplayed=false;
//		while (!isEnteredMonthDisplayed) {
//			currentMonth=getTextFromElement(lblMonth, "Current Month");
//			if(!(currentMonth.equalsIgnoreCase(monthToBeEntered))) {
//				touchAction.tap(PointOption.point(monthNextX, monthNextY))
//				.waitAction(WaitOptions.waitOptions(Duration.ofMillis(1000))).release().perform();
//			}
//			else {
//				isEnteredMonthDisplayed =true;
//				break;
//			}
//
//		}
//
//		Point datePoint = ((MobileElement) lblDate).getCenter();
//		int dateNextX=datePoint.getX();
//		int dateY=yearPoint.getY();
//		int dateNextY;
//
//		String currentDate = getTextFromElement(lblDate, "Current Date");
//		int dateDiff = Integer.parseInt(dateToBeEntered) - Integer.parseInt(currentDate);
//		System.out.println(dateDiff);
//		int dateCount=0;
//		if(dateDiff>0) {
//			dateNextY=dateY+IncreaseY;
//			while (dateCount < dateDiff) {
//				dateCount =dateCount + 1;
//				touchAction.tap(PointOption.point(dateNextX, dateNextY)).release().perform();
//			}
//
//		}
//		else if(dateDiff<0){
//			dateNextY=dateY-IncreaseY;
//			dateDiff=Math.abs(dateDiff);
//			while (dateCount < dateDiff) {
//				dateCount =dateCount + 1;
//				touchAction.tap(PointOption.point(dateNextX, dateNextY)).release().perform();
//			}
//		}
//
//
//		clickElement(lstDateTimeTabs.get(1),"Time Tab");
//
//		Point hourPoint = ((MobileElement) lstDateTimeFields.get(0)).getCenter();
//		int hourNextX=hourPoint.getX();
//		int hourY=yearPoint.getY();
//		int hourNextY;
//
//		String currentHour = getTextFromElement(lstDateTimeFields.get(0), "Current Hour");
//
//		int hourDiff = Integer.parseInt(hourToBeEntered) - Integer.parseInt(currentHour);
//		System.out.println(hourDiff);
//		int hourCount=0;
//		if(hourDiff>0) {
//			hourNextY=hourY+IncreaseY;
//			while (hourCount < hourDiff) {
//				hourCount =hourCount + 1;
//				touchAction.tap(PointOption.point(hourNextX, hourNextY)).release().perform();
//			}
//
//		}
//		else if(hourDiff<0){
//			hourNextY=hourY-IncreaseY;
//			hourDiff=Math.abs(hourDiff);
//			while (hourCount < hourDiff) {
//				hourCount =hourCount + 1;
//				touchAction.tap(PointOption.point(hourNextX, hourNextY)).release().perform();
//			}
//		}
//
//		Point minutePoint = ((MobileElement) lstDateTimeFields.get(1)).getCenter();
//		int minuteNextX=minutePoint.getX();
//		int minuteY=yearPoint.getY();
//		int minuteNextY;
//
//		String currentMinute = getTextFromElement(lstDateTimeFields.get(1), "Current Minute");
//		int minuteDiff = Integer.parseInt(minuteToBeEntered) - Integer.parseInt(currentMinute);
//		System.out.println(minuteDiff);
//		int minuteCount=0;
//		if(minuteDiff>0) {
//			minuteNextY=minuteY+IncreaseY;
//			while (minuteCount < minuteDiff) {
//				minuteCount =minuteCount + 1;
//				touchAction.tap(PointOption.point(minuteNextX, minuteNextY)).release().perform();
//			}
//
//		}
//		else if(minuteDiff<0){
//			minuteNextY=minuteY-IncreaseY;
//			minuteDiff=Math.abs(minuteDiff);
//			while (minuteCount < minuteDiff) {
//				minuteCount =minuteCount + 1;
//				touchAction.tap(PointOption.point(minuteNextX, minuteNextY)).release().perform();
//			}
//		}
//
//		Point meridiemPoint = ((MobileElement) lstDateTimeFields.get(2)).getCenter();
//
//		int meridiemNextX=meridiemPoint.getX();
//		int meridiemY=yearPoint.getY();
//		int meridiemNextY; 
//
//		String currentMeridiem=getTextFromElement(lstDateTimeFields.get(2),"Current Meridiem");
//
//		if(!(meridiemToBeEntered.equalsIgnoreCase(currentMeridiem))) {
//
//			if(currentMeridiem.equalsIgnoreCase("AM")) {
//				meridiemNextY=meridiemY+IncreaseY;
//			}
//			else {
//				meridiemNextY=meridiemY-IncreaseY;
//			}
//
//			touchAction.tap(PointOption.point(meridiemNextX, meridiemNextY)).release().perform();
//		}
//
//		clickElement(btnOKDate,"Done");
//
//	}
//}
