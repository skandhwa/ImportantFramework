package com.slb.utilities;

//Reference Links :
//https://stackoverflow.com/questions/31539242/selenium-webdriver-page-object-pattern-and-extentreports
//http://www.softwaretestingmaterial.com/generate-extent-reports/

import java.io.File;
import java.util.Date;

import com.relevantcodes.extentreports.DisplayOrder;
import com.relevantcodes.extentreports.ExtentReports;
//import com.slb.pom.testUtils.globalVariables;

public class ExtentManager {
	private static ExtentReports extent;

	public static ExtentReports getInstance() {
		if (extent == null) {
			Date d=new Date();
			//String fileName=d.toString().replace(":", "_").replace(" ", "_")+".html";
			String fileName="ExecutionReport.html";
			String reportPath =globalVariables.Extent_Report_Path+fileName;
			extent = new ExtentReports(reportPath, true, DisplayOrder.OLDEST_FIRST);
//			extent = new ExtentReports(reportPath, true, DisplayOrder.NEWEST_FIRST);
			extent.loadConfig(new File(System.getProperty("user.dir")+"//ReportsConfig.xml"));
			
			//extent.addSystemInfo("Selenium Version", "2.53.0").addSystemInfo("Environment", "QA");
			//extent.setSystemInfo("Selenium Version", "3.11.0");
			//extent.setSystemInfo("Environment", "QA");
			
			extent.addSystemInfo("Selenium Version", "3.11.0");
			extent.addSystemInfo("Environment", "QA");
			
		}
		return extent;
	}
}
