package com.slb.utilities;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Properties;
import java.util.Set;

import javax.imageio.ImageIO;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.Alert;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
//import org.openqa.selenium.interactions.touch.TouchActions;
import org.openqa.selenium.remote.RemoteWebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.PerformsTouchActions;
//import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSDriver;
//import io.appium.java_client.android.AndroidKeyCode;
import io.appium.java_client.touch.WaitOptions;
import io.appium.java_client.touch.offset.PointOption;

public class CommonFunctions {

	// **************** Global Variables
	// ******************************************************

	String filePath;
	String ExpectedText = "";
	String ActualText = "";
	public static AppiumDriver driver;
	public WebDriver driver1;
	public ExtentTest test;
	boolean isElementFound;
	boolean isElement2Found = false;
	public String elementName = "";
	public Logger logger = Logger.getLogger(CommonFunctions.class);
	ArrayList<String> listItems;
	public static ClassLoader basedir;
	public static String fileLocation = "C:\\mobileAutomation_git_push\\Appium%20Base%20Framework\\AppiumBDDFramework\\resources\\config.properties";
	public static Properties prop;

	// **************** Constructors
	// ******************************************************

//	public CommonFunctions(AppiumDriver driver, ExtentTest test, WebDriver driver1) {
//
//		this.driver = driver;
//		this.driver1 = driver1;
//		this.test = test;
//	}
//	
	public Properties readDatafromConfig() throws Exception {
		BufferedReader reader = new BufferedReader(new FileReader(fileLocation));
		prop = new Properties();
		prop.load(reader);
		return prop;
	}

	// ******Switching to Frame Using Index******//
	public void DriverFocusOnPage() {

		driver1.switchTo().frame(2);

	}

	public void mobileDriverFocusOnPage() {

		driver.switchTo().frame(2);

	}

	 public static void scroll(AppiumDriver driver) {
	        int startX = (int) (driver.manage().window().getSize().getWidth() * 0.5);
	        int startY = (int) (driver.manage().window().getSize().getHeight() * 0.8);
	        int endY = (int) (driver.manage().window().getSize().getHeight() * 0.2);
	        TouchAction touchAction = new TouchAction((PerformsTouchActions) driver);
	        touchAction.press(PointOption.point(startX, startY)).moveTo(PointOption.point(startX, endY)).release().perform();
	    }
	// ******Scroll down to till Web Element is Visible******//
	public void scrolldownbrowser(WebElement Elem) {
		JavascriptExecutor js = (JavascriptExecutor) driver1;
		js.executeScript("arguments[0].scrollIntoView();", Elem);
	}

	// ******Enter the Text in Text Field******//
	public void enterText(WebElement elem, String enterText, String elemName) {
		isElementFound = waitTillVisible(elem, elemName);
		if (isElementFound) {
			elem.sendKeys(enterText);
			test.log(LogStatus.PASS, "Text - " + enterText + " - entered successfully on element - " + elemName);
		} else {
			test.log(LogStatus.FAIL, "Text - " + enterText + " -  is NOT entered on element - " + elemName);
		}

	}

	// ******Page Refresh Method for Web******//
	public void PageReload() {
		driver1.navigate().refresh();
	}

	// ******Accepting Alert******//

	public void alertAccept() {
		Alert alert;
		alert = driver1.switchTo().alert();
		alert.accept();
	}

	// ******Rejecting Alert******//
	public void alertReject() {
		Alert alert = driver.switchTo().alert();
		alert.dismiss();
	}

	// ******Get Text from Alert******//
	public String alertGetText() {
		Alert alert = driver.switchTo().alert();
		return alert.getText();
	}

	/*
	 * To validate whether element is displayed.
	 * 
	 */
	public boolean isElementDisplayed(WebElement elem, String elemName) {

		elementName = elemName;

		logger.info("Checking the whether '" + elemName + "' is Displayed");

		isElementFound = waitTillVisible(elem, elemName);

		if (isElementFound)

			if (elem != null && elem.isDisplayed()) {
				logger.info("Element - " + elemName + " - is found on the screen");
				test.log(LogStatus.PASS, "Element - " + elemName + " - is found on the screen");
			} else {
				logger.info("Element - " + elemName + " - is not found on the screen");
				test.log(LogStatus.FAIL, "Element - " + elemName + " - is not found on the screen");
			}

		return isElementFound;
	}

	public void isElementListDisplayed(List<WebElement> ele, String elementName) {

		for (int i = 0; i < ele.size(); i++) {
			isElementDisplayed(ele.get(i), elementName);
		}

	}

	/*
	 * To Verify Actual is same as expected output.
	 */
	public void verifyTextOnElement(WebElement elem, String ExpectedTextReceived, String elemName) throws IOException {

		try {
			if (DeviceMap.valueOf(readDatafromConfig().getProperty("strDeviceName")).getPlatformName()
					.equalsIgnoreCase("Android")) {
				logger.info("Verifying the " + ExpectedTextReceived);
				isElementFound = waitTillVisible(elem, elemName);
				ExpectedText = ExpectedTextReceived.trim();
				ActualText = elem.getText().trim();
				if (isElementFound) {
					if (ActualText.equalsIgnoreCase(ExpectedText)) {
						test.log(LogStatus.PASS, "The Text / Label <b>'" + ExpectedText + "'</b> is found");
					} else {
						test.log(LogStatus.FAIL, "The Text / Label <b>'" + ExpectedText + "'</b> is NOT found");
						takeScreenshot();
						// markScreenshot(elem);
						logger.info("Screenshot attached and marked");
					}
				}
			} else {
				logger.info("Verifying the " + ExpectedTextReceived);
				isElementFound = waitTillVisible(elem, elemName);
				ExpectedText = ExpectedTextReceived.trim();
				ActualText = elem.getAttribute("value");
				if (isElementFound) {
					if (ActualText.equalsIgnoreCase(ExpectedText)) {
						test.log(LogStatus.PASS, "The Text / Label <b>'" + ExpectedText + "'</b> is found");
					} else {
						test.log(LogStatus.FAIL, "The Text / Label <b>'" + ExpectedText + "'</b> is NOT found");
						takeScreenshot();
						// markScreenshot(elem);
						logger.info("Screenshot attached and marked");
					}
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			logger.info("Exception occured inside the verifyText() ");
		}

	}

	public void verifyTextfromTwoElement(WebElement elem1, WebElement elem2, String elemName1, String elemName2,
			String strDeviceName) throws IOException {

		try {
			if (DeviceMap.valueOf(readDatafromConfig().getProperty("strDeviceName")).getPlatformName()
					.equalsIgnoreCase("Android")) {
				logger.info("Verifying the text from  " + elemName1 + " and " + elemName2);
				isElementFound = waitTillVisible(elem1, elemName1);
				isElement2Found = waitTillVisible(elem2, elemName2);
				ActualText = elem1.getText().trim();
				ExpectedText = elem2.getText().trim();
				if (isElementFound && isElement2Found) {
					if (ActualText.equalsIgnoreCase(ExpectedText)) {
						test.log(LogStatus.PASS, "The Text / Label <b>'" + ExpectedText + "'</b> is  Matched");
					} else {
						test.log(LogStatus.FAIL,
								"The Text / Label <b>'" + ExpectedText + " and " + ActualText + "'</b> is NOT MATCHED");
						takeScreenshot();
						logger.info("Screenshot attached and marked");
					}
				}
			} else {
				logger.info("Verifying the text from  " + elemName1 + " and " + elemName2);
				isElementFound = waitTillVisible(elem1, elemName1);
				isElement2Found = waitTillVisible(elem2, elemName2);
				ActualText = elem1.getAttribute("value");
				ExpectedText = elem2.getAttribute("value");
				if (isElementFound && isElement2Found) {
					if (ActualText.equalsIgnoreCase(ExpectedText)) {
						test.log(LogStatus.PASS, "The Text / Label <b>'" + ExpectedText + "'</b> is  Matched");
					} else {
						test.log(LogStatus.FAIL,
								"The Text / Label <b>'" + ExpectedText + " and " + ActualText + "'</b> is NOT MATCHED");
						takeScreenshot();
						logger.info("Screenshot attached and marked");
					}
				}
			}
		} catch (Exception e) {
			logger.info("Exception occured inside the verifyText() ");
		}

	}

	/*
	 * To Get the ElementText
	 */
	public String getTextFromElement(WebElement elem, String elementName) throws IOException {

		try {
			if (DeviceMap.valueOf(readDatafromConfig().getProperty("strDeviceName")).getPlatformName()
					.equalsIgnoreCase("Android")) {
				logger.info("Getting the text from the element -" + elementName);

				isElementFound = waitTillVisible(elem, elementName);

				if (isElementFound) {

					ActualText = elem.getText().trim();

					logger.info("Text retrieved from the element -" + elementName + " : " + ActualText);
				}
			} else {
				logger.info("Getting the text from the element -" + elementName);

				isElementFound = waitTillVisible(elem, elementName);

				if (isElementFound) {

					ActualText = elem.getAttribute("value").trim();

					logger.info("Text retrieved from the element -" + elementName + " : " + ActualText);
				}
			}
		} catch (Exception e) {
			logger.info("Exception occured inside the GetText_from_Element() ");
		}
		return ActualText;

	}

	public void clearElement(WebElement elem) {

		try {
			logger.info("Clearing the Field");

			// isElementFound= waitTillVisible(elem);

			if (isElementFound) {

				elem.clear();
			}

		} catch (Exception e) {
			logger.info("Exception occured inside the clear() ");
		}
	}

	/*
	 * To click the element
	 */
	public void clickElement(WebElement elem, String elementLable) {

		isElementFound = waitTillVisible(elem, elementLable);
		if (isElementFound) {
			elem.click();
			logger.info("Element - " + elem + " - is found on the screen and getting clicked");
			test.log(LogStatus.PASS, " Clicked on  <b>'" + elementLable + "'</b> element");
		}

		else {
			test.log(LogStatus.FAIL, "Unable to Click on  <b>'" + elementLable + "'</b> element");

		}

	}

	/*
	 * To wait until visibility of element.
	 */
	public boolean waitTillVisible(WebElement elem, String ElementName) {
		logger.info(" Inside the waitTillVisible()");
		// driver.context("NATIVE_APP");
		try {
			if (DriverIntialization.parameterName.equalsIgnoreCase("Browser")) {
				System.out.println("inside wait");
				//WebDriverWait waitForElement = new WebDriverWait(driver1, 20);
				WebDriverWait waitForElement = new WebDriverWait(driver1,Duration.ofSeconds(20));

				waitForElement.until(ExpectedConditions.visibilityOf(elem));

				return true;
			}

//				Wait<AppiumDriver> waitForElement = new FluentWait<AppiumDriver>(driver).withTimeout(Duration.ofSeconds(20)).pollingEvery(Duration.ofSeconds(3)).ignoring(NoSuchElementException.class);
//				waitForElement.until(ExpectedConditions.visibilityOf(elem));

			return true;

		} catch (Exception e) {

			logger.info("Inside the catch block of waitTillVisible");
			logger.info(e.getMessage());
			logger.info(ElementName + " Element Not Found' Exception occured");
			test.log(LogStatus.ERROR, ElementName + " 'Element Not Found' Exception occured !");
			takeScreenshot();
			logger.info("Screenshot captured.");
			return false;

		}
	}

	public void takeScreenshot() {

		logger.info("Inside the takeScreenShot() ");

		try {
			Date d = new Date();

			String screenshotFile = d.toString().replace(":", "_").replace(" ", "_") + ".png";
			filePath = globalVariables.Extent_Screenshots_Path + screenshotFile;
			File scrFile = ((TakesScreenshot) driver1).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(scrFile, new File(filePath));
			test.log(LogStatus.INFO, test.addScreenCapture(filePath));
		} catch (IOException e) {
			logger.info("Inside TakeScreenshot Exception catch");
			logger.info(e.getMessage());

		}

		logger.info("end of the takeScreenShot() ");

	}

	/*
	 * To mark element in Red color where actual value does not match with expected
	 * value.
	 */
	public void markScreenshot(WebElement elem) throws IOException {
		logger.info("Inside the markScreenshot()");

		try {
			BufferedImage image = ImageIO.read(new File(filePath));
			Graphics2D graphics = image.createGraphics();
			// to get the position and dimension of the element
			int x = elem.getLocation().getX();
			int y = elem.getLocation().getY();
			int width = elem.getSize().getWidth();
			int height = elem.getSize().getHeight();
			logger.info("Drawing rectangle at " + x + ", " + y + ", " + width + ", " + height);
			graphics.setColor(Color.RED);
			graphics.setStroke(new BasicStroke(8.0f));
			graphics.drawRect(x, y, width, height);

			ImageIO.write(image, "png", new File(filePath));
		} catch (Exception e) {
			logger.info("Inisde the catch block of markScreenshot()");
			logger.info(e.getMessage());
			logger.info("Unable to mark the screenshot as Element not Found to mark");
		}
	}

	public void compareString(String textX, String textY) {
		try {

			if (textX.equalsIgnoreCase(textY)) {
				logger.info("TextX are same as TextY");
				test.log(LogStatus.PASS, " The String  <b>'" + textX + "'</b> and <b>'" + textY + "'</b> are matched");

			} else {
				logger.info("TextX are  Not as TextY");
				test.log(LogStatus.PASS, " The String  <b>'" + textX + "'</b> and <b>'" + textY + "'</b> are matched");
			}
		} catch (Exception e) {
			logger.info("Inside the exception block of compareString() method");
		}
	}

//	public ArrayList<String> RetrieveListElement(List<WebElement> listElem, int scrollLimit) {
//
//		try {
//			logger.info("inside the RetrieveListElement() method");
//			if (scrollLimit == 0) {
//				listItems = new ArrayList<String>();
//				int size = listElem.size();
//				logger.info("Total number of Items are ---" + listElem.size());
//				for (int i = 0; i < size; i++) {
//					String s = listElem.get(i).getText();
//					listItems.add(s);
//				}
//
//				Set<String> hs = new LinkedHashSet<String>(); // this created to remove the duplicates.
//				hs.addAll(listItems);
//				listItems.clear();
//				listItems.addAll(hs);
//
//			} else if (scrollLimit > 0) {
//
//				String firstElement = listElem.get(0).getText();
//				logger.info("First Element name is : ---" + firstElement);
//
//				Dimension size1 = driver.manage().window().getSize();
//
//				int starty = (int) (size1.height * 0.90);
//				int endy = (int) (size1.height * 0.40);
//				int x = size1.width / 2;
//				int limit = 1;
//
//				TouchAction touchAction = new TouchAction(driver);
//
//				// Swiping till end of the page.
//
//				do {
//
//					touchAction.press(PointOption.point(x, starty))
//							.waitAction(WaitOptions.waitOptions(Duration.ofMillis(2000)))
//							.moveTo(PointOption.point(x, endy)).release().perform();
//
//					limit++;
//				} while (limit < scrollLimit);
//
//				// Found the last element of the page.
//				String lastElement = listElem.get(listElem.size() - 1).getText();
//				logger.info("Last Element name is : ---" + lastElement);
//
//				logger.info("Started Scrolling back to first page");
//				int limit1 = 1;
//				do {
//					touchAction.press(PointOption.point(x, endy))
//							.waitAction(WaitOptions.waitOptions(Duration.ofMillis(2000)))
//							.moveTo(PointOption.point(x, starty)).release().perform();
//					limit1++;
//				} while (limit1 < scrollLimit);
//
//				logger.info("Scrolled to first page");
//
//				boolean found = false;
//				boolean found_result = false;
//
//				listItems = new ArrayList<String>();
//
//				while (!found_result) {
//					int size = 0;
//					size = size + listElem.size();
//
//					for (int i = 0; i < size; i++) {
//						String s = listElem.get(i).getText();
//						listItems.add(s);
//
//						if (s.contains(lastElement.trim())) {
//							found = true;
//							break;
//						}
//					}
//					if (!found) {
//						touchAction.press(PointOption.point(x, starty))
//								.waitAction(WaitOptions.waitOptions(Duration.ofMillis(2000)))
//								.moveTo(PointOption.point(x, endy)).release().perform();
//					} else
//						break;
//				}
//
//				logger.info("Total list items during Swipe including duplicates----" + listItems.size());
//
//				Set<String> hs = new LinkedHashSet<String>(); // this created to remove the duplicates.
//				hs.addAll(listItems);
//				listItems.clear();
//				listItems.addAll(hs); // All duplicates list items are removed, only unique items are copied to
//										// arrayList.
//			}
//
//		} catch (Exception e) {
//			logger.info("inside exception block of RetrieveListElement() mehtod");
//			logger.info(e.getMessage());
//		}
//		return listItems;
//	}

	/*
	 * Get Element Size
	 */
	public int getElementSize(List<WebElement> elem) {
		return elem.size();
	}

	/*
	 * Scroll Down till Element Visible in Android
	 */
//	public void scrollDownUntilElementVisible(List<WebElement> elem) {
//
//		logger.info("Inside the scrollDownUntilElementVisible()");
//
//		TouchAction touchAction = new TouchAction(driver);
//
//		int count = 0;
//
//		for (int i = 0; i < 12; i++) {
//
//			logger.info("Checking if the element is displayed");
//
//			count = elem.size();
//			logger.info("Count : " + count);
//
//			if (count > 0) {
//				break;
//			} else {
//				logger.info("Element is not visible. Scrolling down");
//
//				/*
//				 * int pressX = driver.manage().window().getSize().width / 2; int bottomY =
//				 * driver.manage().window().getSize().height * 4/5; int topY =
//				 * driver.manage().window().getSize().height / 8;
//				 * 
//				 * touchAction.longPress(PointOption.point(pressX,
//				 * bottomY)).waitAction(WaitOptions.waitOptions(Duration.ofMillis(1000))).moveTo
//				 * (PointOption.point(pressX, topY)).release().perform();
//				 */
//				int pressX = driver.manage().window().getSize().width / 2;
//				int bottomY = driver.manage().window().getSize().height * 3 / 5;
//				int topY = driver.manage().window().getSize().height * 2 / 5;
//
//				touchAction.longPress(PointOption.point(pressX, bottomY)).moveTo(PointOption.point(pressX, topY))
//						.release().perform();
//
//			}
//		}
//	}

	/*
	 * Scroll Down Number of Times for Android
	 */
//	public void scrollDownTimes(int iScrollDown) {
//		logger.info("Inside the scrollDownTimes()");
//
//		TouchAction touchAction = new TouchAction(driver);
//
//		for (int i = 0; i < iScrollDown; i++) {
//
//			logger.info("Scrolling down for " + (i + 1) + "th time");
//
//			try {
//				Thread.sleep(4000);
//			} catch (InterruptedException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//			int pressX = driver.manage().window().getSize().width / 2;
//			int bottomY = driver.manage().window().getSize().height * 3 / 5;
//			int topY = driver.manage().window().getSize().height * 2 / 5;
//
//			touchAction.longPress(PointOption.point(pressX, bottomY)).moveTo(PointOption.point(pressX, topY)).release()
//					.perform();
//
//		}
//	}
//
//	/*
//	 * Scroll Down for Android
//	 */
//	public void scrolldownwards(WebElement element) {
//		TouchActions action = new TouchActions(driver);
//		action.scroll(element, 10, 100);
//		action.perform();
//	}

	/*
	 * Scroll Left for Number of Times for Android
	 */
//	public void scrollLeft(int scrollLeft) {
//
//		logger.info("Inside the scroll leftTimes()");
//
//		TouchAction touchAction = new TouchAction(driver);
//
//		for (int i = 0; i < scrollLeft; i++) {
//
//			logger.info("Scrolling left for " + (i + 1) + "th time");
//
//			int pressX = driver.manage().window().getSize().width / 2;
//			int bottomY = driver.manage().window().getSize().width * 3 / 5;
//			int topY = driver.manage().window().getSize().width * 2 / 5;
//
//			touchAction.longPress(PointOption.point(pressX, bottomY)).moveTo(PointOption.point(pressX, topY)).release()
//					.perform();
//
//		}
//	}

	/*
	 * Scroll Right for Number of Times for Android
	 */
//	public void scrollRight(int ScrollRight) {
//
//		logger.info("Inside the scroll Right Times()");
//
//		TouchAction touchAction = new TouchAction(driver);
//
//		for (int i = 0; i < ScrollRight; i++) {
//
//			logger.info("Scrolling right for " + (i + 1) + "th time");
//
//			int pressX = driver.manage().window().getSize().width / 2;
//			int bottomY = driver.manage().window().getSize().height * 3 / 5;
//			int topY = driver.manage().window().getSize().height * 2 / 5;
//
//			touchAction.longPress(PointOption.point(pressX, bottomY)).moveTo(PointOption.point(pressX, topY)).release()
//					.perform();
//
//		}
//	}

	/*
	 * Scroll Up for Number of Times for Android
	 */
//	public void scrollUpTimes(int iScrollDown) {
//
//		logger.info("Inside the scrollDownTimes()");
//
//		TouchAction touchAction = new TouchAction(driver);
//
//		for (int i = 0; i < iScrollDown; i++) {
//
//			logger.info("Scrolling up for " + (i + 1) + "th time");
//
//			int pressX = driver.manage().window().getSize().width / 2;
//			int bottomY = driver.manage().window().getSize().height * 2 / 5;
//			int topY = driver.manage().window().getSize().height * 3 / 5;
//
//			touchAction.longPress(PointOption.point(pressX, bottomY)).moveTo(PointOption.point(pressX, topY)).release()
//					.perform();
//
//		}
//	}

	/*
	 * Scroll Down Height Between Bottom Element and Top Element for Android
	 */
//	public void scrollDownForHeightBetween(WebElement bottomElem, WebElement topElem) {
//
//		logger.info("Inside the scrollDownForHeightBetween()");
//
//		TouchAction touchAction = new TouchAction(driver);
//
//		int pressX = bottomElem.getLocation().getX();
//		int bottomY = bottomElem.getLocation().getY();
//		int topY = topElem.getLocation().getY();
//
//		logger.info("Scrolling down for the Height : " + (bottomY - topY));
//
//		touchAction.longPress(PointOption.point(pressX, bottomY))
//				.waitAction(WaitOptions.waitOptions(Duration.ofMillis(2000))).moveTo(PointOption.point(pressX, topY))
//				.waitAction(WaitOptions.waitOptions(Duration.ofMillis(2000))).release().perform();
//
//	}

	/*
	 * Tap Enter Key
	 */
//	public void tapEnterKey(String Platform) {
//		if (Platform.equalsIgnoreCase("Android")) {
//			System.out.println("Android");
//			((AndroidDriver) driver).pressKeyCode(AndroidKeyCode.KEYCODE_ENTER);
//		} else if (Platform.equalsIgnoreCase("iOS")) {
//			((IOSDriver) driver).getKeyboard().sendKeys(Keys.ENTER);
//		}
//
//	}

	/*
	 * Number Field Validation
	 */
	public void VerifyNumberFieldValidation(WebElement WBE) {
		WBE.sendKeys("hsdjfhjfs");
		System.out.println("text 1 = " + WBE.getAttribute("value"));

		try {
			if (!(WBE.getAttribute("value").equals(null))) {
				test.log(LogStatus.FAIL, "Alphabets should not allowed in Number fields");
				test.log(LogStatus.INFO, WBE.getAttribute("value"));
				takeScreenshot();
			}
		}

		catch (NullPointerException e) {

			e.printStackTrace();// TODO: handle exception
			System.out.println("strings did not entered");
		}
		WBE.clear();
		WBE.sendKeys("@#$%^&");
		System.out.println(WBE.getText());

		try {

			if (!(WBE.getAttribute("value").equals(null))) {
				test.log(LogStatus.FAIL, "Special characters should not allowed in Number fields");
				test.log(LogStatus.INFO, WBE.getAttribute("value"));
				takeScreenshot();
			}

		} catch (NullPointerException e) {

			e.printStackTrace();// TODO: handle exception
			System.out.println("strings did not entered");
		}
		WBE.clear();
		WBE.sendKeys("     ");

		try {

			if (!(WBE.getAttribute("value").equals(null))) {
				test.log(LogStatus.FAIL, "Blank space characters should not allowed in Number fields");
				test.log(LogStatus.INFO, WBE.getAttribute("value"));
				takeScreenshot();
			}
		} catch (NullPointerException e) {

			e.printStackTrace();// TODO: handle exception
			System.out.println("strings did not entered");
		}

		WBE.clear();

	}

	/*
	 * public void SwitchToAlert(){ driver1.switchTo().defaultContent(); }
	 */

	public void SwitchToDefault() {
		driver1.switchTo().defaultContent();
	}

	/*
	 * Drop Down Select
	 */
	public void SelectDropdown(WebElement elem, String ElementName, String Value) {
		System.out.println("inside select1");
		isElementFound = waitTillVisible(elem, ElementName);
		if (isElementFound) {
			System.out.println("inside select2");
			Select dropdown = new Select(elem);
			dropdown.selectByValue(Value);
		}

	}

	/*
	 * Switch to Frame
	 */
	public void SwitchToframe(int index) {
		driver1.switchTo().frame(index);
	}

	/*
	 * looks for Web Element in specified direction (Only in iOS)
	 */
	public static boolean scroll_iOS_XCTest(WebElement el, String direction) {

		try {
			JavascriptExecutor js = (JavascriptExecutor) driver;
			HashMap<String, String> scrollObject = new HashMap<String, String>();
			if (direction.equals("d")) {
				scrollObject.put("direction", "down");
			} else if (direction.equals("u")) {
				scrollObject.put("direction", "up");
			} else if (direction.equals("l")) {
				scrollObject.put("direction", "left");
			} else if (direction.equals("r")) {
				scrollObject.put("direction", "right");
			}
			scrollObject.put("element", ((RemoteWebElement) el).getId());
			scrollObject.put("toVisible", "true"); // optional but needed sometimes
			js.executeScript("mobile:scroll", scrollObject);

			System.out.println("Scrolling is completed in driection : " + direction);

			return true;
		} catch (Exception e) {
			return false;
		}
	}

	/*
	 * Look for text in iOS in specified direction
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static void ScrollItemByDescription(String text, String direction) {

		System.out.println("Scroll by description : " + text);

		JavascriptExecutor js = (JavascriptExecutor) driver;
		HashMap scrollObject = new HashMap<>();
		if (direction.equals("d")) {
			scrollObject.put("direction", "down");
		} else if (direction.equals("u")) {
			scrollObject.put("direction", "up");
		} else if (direction.equals("l")) {
			scrollObject.put("direction", "left");
		} else if (direction.equals("r")) {
			scrollObject.put("direction", "right");
		}
		scrollObject.put("predicateString", "value == '" + text + "'");
		js.executeScript("mobile: scroll", scrollObject);

	}

	/*
	 * Return label of an element in lower case with trimmed
	 */
	public String returnLblOfElementInLowerCase(WebElement lblElement) {
		String currentLabel = null;
		try {
			if (DeviceMap.valueOf(readDatafromConfig().getProperty("strDeviceName")).getPlatformName()
					.equalsIgnoreCase("Android")) {
				System.out.println("platfrom name : Android");
				currentLabel = lblElement.getText().trim().toLowerCase();
				System.out.println("Text returned from appium is  : " + currentLabel);
			} else {
				System.out.println("platfrom name : iOS");
				currentLabel = lblElement.getAttribute("label").trim().toLowerCase();
				System.out.println("Text returned from appium is  : " + currentLabel);
			}
		} catch (Exception e) {
			System.out.println("Exception while trying to retrive label value");
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		return currentLabel;
	}

	/*
	 * Verify Partial text of element
	 */
	public boolean verifyParitalTxt(WebElement elementToVefiryText, String partialText) {
		boolean flag = false;
		try {
			System.out.println("Text being verified is        : " + partialText);
			System.out.println("Verifying parital text because of technical limitation");
			Assert.assertTrue(returnLblOfElementInLowerCase(elementToVefiryText).contains(partialText.toLowerCase()));
			System.out.println("Text is verified");
			flag = true;
		} catch (Exception e) {
			flag = false;
			e.printStackTrace();
			System.out.println("Unable to verify Text " + e.getMessage());
		}
		return flag;
	}

	/*
	 * Verify Exact text of element
	 */
	public boolean verifyExactTxt(WebElement elementToVefiryText, String exactText) {
		boolean flag = false;
		try {
			System.out.println("Text being verified is        : " + exactText);
			System.out.println("Verifying exact text");
			Assert.assertTrue(returnLblOfElementInLowerCase(elementToVefiryText).contains(exactText.toLowerCase()));
			System.out.println("Text is verified");
			flag = true;
		} catch (Exception e) {
			flag = false;
			e.printStackTrace();
			System.out.println("Unable to verify Text " + e.getMessage());
			Assert.fail();
		}
		return flag;
	}

	/*
	 * Creates Id for sequential list in iOS for 100 locators by default input
	 * arguments : prefix and suffix and number of id's that needed to be generated
	 * 
	 */
	public static List<String> returnListOfIDs(String prefixPartOfId, String suffixPartOfId,
			int numOfSequentialIdsNeed) {
		List<String> idListForIOS = new ArrayList<String>();
		try {
			System.out.println("Creating list of ID's");
			for (int i = 1; i <= numOfSequentialIdsNeed; i++) {
				String currentId = prefixPartOfId + i + suffixPartOfId;
				idListForIOS.add(currentId);
			}
			System.out.println("Created ID's successfully ");
			System.out.println(idListForIOS.toString());
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Unable to Create list of ID's for iOS : " + e.getMessage());
			Assert.fail();
		}
		System.out.println("List of locators created is ::" + idListForIOS);
		return idListForIOS;

	}

}
