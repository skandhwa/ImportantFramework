package com.slb.utilities;

import org.openqa.selenium.By;
import org.openqa.selenium.interactions.*;

import io.appium.java_client.pagefactory.AndroidFindBy;

public class LoginPage extends DriverIntialization {
	
	
	    
	    public void setEmail(String email) {
	        try {
				//emailField.sendKeys(email);
				driver.findElement(By.xpath("//XCUIElementTypeApplication[1]/XCUIElementTypeWindow[1]/XCUIElementTypeOther[1]/XCUIElementTypeTextField[1]")).sendKeys("email");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    }

	    public void setPassword(String password) {
	    	try
	    	{
	    		driver.findElement(By.xpath("//XCUIElementTypeApplication[1]/XCUIElementTypeWindow[1]/XCUIElementTypeOther[1]/XCUIElementTypeSecureTextField[1]")).sendKeys("password");
	    }catch(Exception e)
	    	{
	    		e.printStackTrace();
	    		}
	    }
	    public  void clickLogin() {
	    	
	    	try
	    	{
	    	driver.findElement(By.xpath("//XCUIElementTypeApplication[1]/XCUIElementTypeWindow[1]/XCUIElementTypeOther[1]/XCUIElementTypeButton[1]")).click();
	    	}
	    	catch(Exception e)
	    	{
	    		e.printStackTrace();
	    		}
	    }

}
