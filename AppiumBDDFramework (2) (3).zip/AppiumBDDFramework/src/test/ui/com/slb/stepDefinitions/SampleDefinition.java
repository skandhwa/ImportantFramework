package com.slb.stepDefinitions;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;

import io.appium.java_client.AppiumDriver;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.slb.pages.SamplePage;
import com.slb.utilities.CommonFunctions;
import com.slb.utilities.DriverIntialization;
import com.slb.utilities.LoginPage;
;

public class SampleDefinition extends DriverIntialization{ 
	
	String sessionId;
	public Logger logger = Logger.getLogger(SampleDefinition.class);
	@Given("User connect to device")
	public void user_connect_to_device() throws Exception {
		DOMConfigurator.configure("log-setup.xml");
		logger.info("Inside the Initialization() @BeforeSuite ");
		//startAppiumServer();
		
		//driverSetup("Emualator_Device", "Emulator_test","");
		//launchApp("ApiDemos-debug", "Emualator_Device", "", "");
		//driverSetup("iPhone11", "App","");
		driverSetup("iPhone11", "CMMS_App","");
		launchApp("Svc&AssetMgr", "iPhone11", "", "");
		//driverSetup("PCloudy", "CMMS_App","");
		//launchApp("Svc&AssetMgr", "PCloudy", "", "");
		//driverSetup("iPhone14_H", "App","");
		//launchApp("Settings", "iPhone14_H", "", "");
		//launchApp("Svc&AssetMgr", "iPhone11", "", "");
		//sessionId = startASession();
		SamplePage sp = new SamplePage(driver,test);
		sp.applicationLogIn();		 
		
		System.out.println("CMMs Test Execution");

	}

	@When("User Execute Equipment Callibration TestCase1")
	public void EquipmentCallibrationTestCase1() throws Exception {
	    
		logger.info("Test Case execution started");
		SamplePage sp = new SamplePage(driver,test);
		sp.OpenWorkOrder();
		sp.AttachDocument();
		sp.syncHalndle();
		//sp.displayAttachedDOC();
		//sp.syncHalndle();
	}
	@When("User Execute Equipment Callibration TestCase2")
	public void EquipmentCallibrationTestCase2() throws Exception {
	    
		logger.info("Test Case execution started");
		SamplePage sp = new SamplePage(driver,test);

		sp.AddPartToWorkOrder();
		sp.syncHalndle();
		sp.IssuePartAddedToWorkOrder();
		sp.syncHalndle();
	}
	@When("User Execute Equipment Callibration TestCase3")
	public void EquipmentCallibrationTestCase3() throws Exception {
	    
		logger.info("Test Case execution started");
		SamplePage sp = new SamplePage(driver,test);
		sp.startWorkOrder();
		sp.syncHalndle();
		sp.resultRecordingForWorkOrder();
		sp.syncHalndle();
		sp.operationConfirmation();
		sp.syncHalndle();
		//sp.WorkOrderComplete();
		//sp.syncHalndle();
	}
	@Then("Complete Work Order")
	public void CompleteWorkOrder() throws Exception {
		
		logger.info("Test Case execution started");
		SamplePage sp = new SamplePage(driver,test);
		sp.WorkOrderComplete();
		stopASession(sessionId);
		sp.syncHalndle();
		//test.log(LogStatus.INFO, "END: To_Verify_SampleTest");
		

		//logger.info("To_Verify_SampleTest execution completed");
		
		
		//logger.info("Inside the @AfterSuite tearDown() method");
//		if (extent != null) {
//			extent.endTest(test);
//			extent.flush();
//		}
//		if (driver != null) {
//			driver.closeApp();
//			driver.quit();
//		}	
	}

	
////	public static AppiumDriver driver;
////	public WebDriver driver1;
////	public ExtentTest test;
//	LoginPage loginpage=new LoginPage();
//	public Logger logger = Logger.getLogger(SampleDefinition.class);
//	@Given("User connect to device")
//	public void user_connect_to_device() throws InterruptedException {
//		DOMConfigurator.configure("log-setup.xml");
//		logger.info("Inside the Initialization() @BeforeSuite ");
//
//		driverSetup("PCloudy_iPhone", "PCloudy_App","");
//		
//		launchApp("PCloudy_App", "PCloudy_iPhone", "", "");
//		System.out.println("completed");
//
//	}
//
//	@When("User click on dummyapp")
//	public void user_click_on_dummyapp() throws Exception {
//	    
//		logger.info("@To_Verify_SampleTest execution started");
//		
//		test = extent.startTest("To_Verify_SampleTest Page");
//		test.log(LogStatus.INFO, "To_Verify_SampleTest");
//		SamplePage sp = new SamplePage(driver,test);
//		sp.sampleMethod();
//	}
//
//	@Then("app will open")
//	public void app_will_open() {
//	   
//		test.log(LogStatus.INFO, "END: To_Verify_SampleTest");
//		
//
//		logger.info("To_Verify_SampleTest execution completed");
//		
//		
//		logger.info("Inside the @AfterSuite tearDown() method");
////		if (extent != null) {
////			extent.endTest(test);
////			extent.flush();
////		}
////		if (driver != null) {
////			driver.closeApp();
////			driver.quit();
////		}	
//	}
//
//	@When("I enter username as {string}")
//	public void i_enter_username_as(String string) {
//	    // Write code here that turns the phrase above into concrete actions
//		loginpage.setEmail(string);
//        logger.info("Email is entered");
//	}
//
//	@When("I enter password as {string}")
//	public void i_enter_password_as(String string) {
//	    // Write code here that turns the phrase above into concrete actions
//		loginpage.setPassword(string);
//        logger.info("Password is entered");
//	}
//
//	@Then("I login")
//	public void i_login() {
//	    // Write code here that turns the phrase above into concrete actions
//		loginpage.clickLogin();
//	}
//
//	
}

