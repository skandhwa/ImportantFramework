package com.slb.pages;

import java.io.IOException;
import java.time.Duration;
import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.xmlbeans.impl.xb.xsdschema.ListDocument.List;
import org.jboss.aerogear.security.otp.Totp;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Optional;
import org.testng.annotations.Test;

import com.google.common.collect.ImmutableMap;
import com.relevantcodes.extentreports.ExtentTest;
import com.slb.utilities.CommonFunctions;
import com.slb.utilities.DriverIntialization;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.PerformsTouchActions;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.touch.offset.PointOption;
//import io.appium.java_client.MobileBy;


public class SamplePage extends CommonFunctions{
	
//	public AndroidDriver<WebElement> driver2;
//	public static AppiumDriver driver;
//	public WebDriver driver1;
//	public ExtentTest test;
//	@AndroidFindBy(id="com.android.camera:id/v9_thumbnail_image") public WebElement ButtonImage;
	
	@FindBy(id = "android:id/edit")
	public WebElement WifiTextField;
//	@FindBy(id = "welcome_tour_got_it")
//	public WebElement gotItButton;
//	
//	@FindBy(id = "setup_addresses_add_another")
//	WebElement addotherEmail;
//	
//	@FindBy(id = "(//*[@id='account_setup_item'])[1]")
//	WebElement accountSetupOption;
//	
//	@FindBy(id = "identifierId")
//	WebElement emailEnterTxtBox;
//	
//	@FindBy(xpath = "(//*[@class='android.widget.Button'])[3]")
//	WebElement nextButton;
//	
//	@FindBy(xpath = "(//*[@class='android.widget.TextView'])[1]")
//	public WebElement apiDemoTitle;

	
	public SamplePage (AppiumDriver driver,ExtentTest test) {
		this.driver = driver;
		this.test = test;
        PageFactory.initElements(driver, this);
	}
	
	public Logger logger = Logger.getLogger(SamplePage.class);

	public void sampleMethod() throws Exception {
		logger.info("Inside sample method");
		try {
			
			driver.findElement(AppiumBy.accessibilityId("Preference")).click();
			
			driver.findElement(By.xpath("//android.widget.TextView[@content-desc='3. Preference dependencies']")).click();
			driver.findElement(By.xpath("//android.widget.CheckBox[@resource-id='android:id/checkbox']")).click();
			driver.findElement(By.xpath("//android.widget.TextView[@text='WiFi settings']")).click();
			
			enterText(WifiTextField, "PraveenWifi", "WifiName");
			logger.info("Wifi Name Entered");
			
			driver.findElements(By.className("android.widget.Button")).get(1).click();
			
		}
		catch (Exception e) {
//			// TODO Auto-generated catch block
			e.printStackTrace();
			return;
		}
		
	}

		public void applicationLogIn() throws Exception {
			logger.info("Inside applicationLogIn method");
			WebElement Display=null;
			String status = "Failed";
			try {
				Display=driver.findElement(AppiumBy.accessibilityId("messageLabel"));
					logger.info("Application Login done, Enter the Passcode");
					driver.findElement(AppiumBy.accessibilityId("show")).click();
					driver.findElement(AppiumBy.accessibilityId("inputField")).sendKeys("12345678");
					driver.findElement(AppiumBy.accessibilityId("doneButton")).click();
					logger.info("Passcode Entered");
					//status = "Passed";
					//JavascriptExecutor js = (JavascriptExecutor)driver;
					//js.executeScript("headspin:quitSession", status);
			}
			catch (Exception e) {
//				// TODO Auto-generated catch block
				//e.printStackTrace();
				logger.info("Application login required");
				driver.findElement(AppiumBy.accessibilityId("confirmButton")).click();
				driver.findElement(AppiumBy.accessibilityId("primaryActionButton")).click();
				//Thread.sleep(3000);
				//driver.findElement(AppiumBy.accessibilityId("Scan new QR code")).click();		//for iPhone13
				//driver.findElement(AppiumBy.accessibilityId("Scan")).click();					//for iPhone13
				driver.findElement(AppiumBy.accessibilityId("choosePhotoButton")).click();
				java.util.List<WebElement> elements = driver.findElements(AppiumBy.accessibilityId("Keep Current Selection"));
				if (!elements.isEmpty()) {
					driver.findElement(AppiumBy.accessibilityId("Keep Current Selection")).click();	
				}
				//driver.findElement(AppiumBy.accessibilityId("Keep Current Selection")).click();
				//java.util.List<WebElement> elements2 = driver.findElements(By.xpath("//XCUIElementTypeImage[@name='Photo, 24 April, 6:37 AM']"));
				
				//if (!elements2.isEmpty()) {
					//driver.findElement(By.xpath("//XCUIElementTypeImage[@name='Photo, 24 April, 6:37 AM']")).click();	
				//}
				//Below locator is for pcloudy iPhone14 QR code
				//driver.findElement(By.xpath("//XCUIElementTypeImage[@name='Photo, 10 May, 6:09 PM']")).click();
				
				//Below locator is for pcloudy iPad6gen QR code
				driver.findElement(By.xpath("//XCUIElementTypeImage[@name='Photo, 16 May, 3:42 PM']")).click();
				
				//Below locator is for iPhone13 QR code
				//driver.findElement(AppiumBy.accessibilityId("Photo, 22 March, 3:13 PM")).click();
				driver.findElement(AppiumBy.accessibilityId("continueButton")).click();
				
				logger.info("QR Scanner selected and Link Opened");
				Thread.sleep(3000);
				driver.findElement(AppiumBy.accessibilityId("someone@slb.com")).click();
				driver.findElement(AppiumBy.accessibilityId("someone@slb.com")).sendKeys("Username@slb.com");
				driver.findElement(By.xpath("(//XCUIElementTypeButton[@name=\"Next\"])[1]")).click();
				driver.findElement(By.xpath("//XCUIElementTypeSecureTextField[contains(@name,'Enter the password')]")).click();
				driver.findElement(By.xpath("//XCUIElementTypeSecureTextField[contains(@name,'Enter the password')]")).sendKeys("Password");
				driver.findElement(AppiumBy.accessibilityId("Sign in")).click();
				
				Totp generateOtp = new Totp("abc");
				System.out.println(generateOtp.now());
				String Var_otp = generateOtp.now();
				driver.findElement(By.xpath("//XCUIElementTypeTextField[@name=\"Enter code\"]")).click();
				driver.findElement(By.xpath("//XCUIElementTypeTextField[@name=\"Enter code\"]")).sendKeys(Var_otp);
				driver.findElement(AppiumBy.accessibilityId("Verify")).click();
				driver.findElement(AppiumBy.accessibilityId("Yes")).click();
				driver.findElement(AppiumBy.accessibilityId("show")).click();
				driver.findElement(AppiumBy.accessibilityId("inputField")).sendKeys("12345678");
				driver.findElement(AppiumBy.accessibilityId("Next")).click();
				driver.findElement(AppiumBy.accessibilityId("show")).click();
				driver.findElement(AppiumBy.accessibilityId("inputField")).sendKeys("12345678");
				driver.findElement(AppiumBy.name("Done")).click();
				WebDriverWait waitForElement = new WebDriverWait(driver, Duration.ofSeconds(120));
				waitForElement.until(ExpectedConditions.visibilityOfElementLocated(AppiumBy.accessibilityId("Update")));
				driver.findElement(AppiumBy.accessibilityId("Update")).click();
				logger.info("App is Updating");
				//WebDriverWait waitForElement2 = new WebDriverWait(driver, Duration.ofSeconds(60));
				//waitForElement2.until(ExpectedConditions.visibilityOfElementLocated(AppiumBy.accessibilityId("Allow")));
				//driver.findElement(AppiumBy.accessibilityId("Allow")).click();
			}
		}
		

		public void OpenWorkOrder() throws Exception {
			logger.info("Inside OpenWorkOrder method");
			String strWorkOrder = "4138119";
			try {
				//Boolean Display=driver.findElement(AppiumBy.accessibilityId("messageLabel")).isDisplayed();
				//if(Display)
				//{
				/*
				 * driver.findElement(AppiumBy.accessibilityId("show")).click();
				 * driver.findElement(AppiumBy.accessibilityId("inputField")).sendKeys(
				 * "12345678");
				 * driver.findElement(AppiumBy.accessibilityId("doneButton")).click();
				 * logger.info("Passcode Entered"); } else {
				 * logger.info("Issue while Entering Passcode"); }
				 */
				WebDriverWait waitForElement = new WebDriverWait(driver, Duration.ofSeconds(300));
				waitForElement.until(ExpectedConditions.visibilityOfElementLocated(AppiumBy.accessibilityId("Toast Message Application Initialized")));
				//Thread.sleep(10000);
				Boolean WorkOrderButton=driver.findElement(By.xpath("//XCUIElementTypeStaticText[@label=\"keyName is Work Orders\"]")).isDisplayed();
				if (WorkOrderButton) {
					driver.findElement(By.xpath("//XCUIElementTypeStaticText[@label=\"keyName is Work Orders\"]")).click();
					System.out.println("Element Clicked");
					driver.findElement(By.xpath("(//XCUIElementTypeSearchField[@name=\"Search\"])[2]")).sendKeys(strWorkOrder);
					Thread.sleep(3000);
					driver.findElement(By.xpath("//XCUIElementTypeStaticText[contains(@name,'Received')]")).click();
					//driver.findElement(By.xpath("//XCUIElementTypeStaticText[contains(@name,'Hold')]")).click();
					logger.info("Work Order Opened");
					}
				else {
					logger.info("Issue while opening Work Order");
				}
				
			}
			catch (Exception e) {
//				// TODO Auto-generated catch block
				logger.info(e.getMessage());
				e.printStackTrace();
				
				return;
			}
			
		}
		public void AttachDocument() throws Exception {	
			logger.info("Inside AttachDocument method");
			try {
			JavascriptExecutor js = (JavascriptExecutor) driver;
			WebElement DocButton = driver.findElement(By.xpath("//XCUIElementTypeStaticText[@label='keyName is Documents']"));
			//MobileElement mobileElement = (MobileElement) DocButton;
			//driver.executeScript("mobile:scroll", ImmutableMap.of("element", ((RemoteWebElement) mobileElement).getId(),"toVisible", true));
			//js.executeScript("mobile:scroll", ImmutableMap.of("element", DocButton));
			//js.executeScript("arguments[0].scrollIntoView(true);", DocButton);
			js.executeScript("mobile:scroll", ImmutableMap.of("direction", "down","distance", "2"));
			DocButton.click();
			Thread.sleep(1000);
			driver.findElement(AppiumBy.accessibilityId("Add")).click();
			driver.findElement(AppiumBy.accessibilityId("Description, Description")).sendKeys("CMMStest");
			driver.findElement(AppiumBy.accessibilityId("Creates a new attachment")).click();
			driver.findElement(AppiumBy.accessibilityId("Take Photo")).click();
			driver.findElement(AppiumBy.accessibilityId("PhotoCapture")).click();
			Thread.sleep(2000);
			driver.findElement(AppiumBy.accessibilityId("Use Photo")).click();
			java.util.List<WebElement> elements = driver.findElements(AppiumBy.accessibilityId("Keep Current Selection"));
			if (!elements.isEmpty()) {
				driver.findElement(AppiumBy.accessibilityId("Keep Current Selection")).click();	
			}
			driver.findElement(AppiumBy.accessibilityId("Continue without Editing")).click();
			driver.findElement(AppiumBy.accessibilityId("Done")).click();

			driver.findElement(By.xpath("//XCUIElementTypeButton[contains(@name,'Work Order')]")).click();
			Thread.sleep(1000);
			driver.findElement(By.xpath("//XCUIElementTypeButton[contains(@name,'Work Orders')]")).click();
			}
		catch (Exception e) {
			logger.info(e.getMessage());
			e.printStackTrace();
			return;
		}
}
		public void displayAttachedDOC() throws Exception{
			logger.info("Display Attached Document");
			try {
				driver.findElement(By.xpath("//XCUIElementTypeStaticText[contains(@name,'Received')]")).click();
				JavascriptExecutor js = (JavascriptExecutor) driver;
				WebElement DocButton = driver.findElement(By.xpath("//XCUIElementTypeStaticText[@label='keyName is Documents']"));
				Thread.sleep(1000);
				js.executeScript("mobile:scroll", ImmutableMap.of("direction", "down","distance", "2"));
				DocButton.click();
				Thread.sleep(1000);
				driver.findElement(By.xpath("//XCUIElementTypeButton[@name='OPEN']")).click();
				driver.findElement(AppiumBy.accessibilityId("Cancel")).click();
				driver.findElement(By.xpath("//XCUIElementTypeButton[contains(@name,'Work Order')]")).click();
				Thread.sleep(1000);
				driver.findElement(By.xpath("//XCUIElementTypeButton[contains(@name,'Work Orders')]")).click();
			}
			catch (Exception e) {
				logger.info(e.getMessage());
				e.printStackTrace();
				return;
			}
		}
		
		public void syncHalndle() throws Exception{
			logger.info("Inside syncHalndle method");
			//try {
			driver.findElement(AppiumBy.accessibilityId("Sync")).click();
			WebDriverWait waitForElement = new WebDriverWait(driver, Duration.ofSeconds(200));
			waitForElement.until(ExpectedConditions.visibilityOfElementLocated(AppiumBy.accessibilityId("Toast Message Sync Successful")));
			logger.info("Sync is Succeessful");
			//}
			//catch (Exception e) {
			/*
			 * logger.info("Error while Sync"); logger.info(e.getMessage());
			 * e.printStackTrace(); return;
			 */
			//}
		}

		public void AddPartToWorkOrder() throws Exception{
			logger.info("Inside AddPartToWorkOrder method");
			try {
				driver.findElement(By.xpath("//XCUIElementTypeStaticText[contains(@name,'Received')]")).click();
				driver.findElement(AppiumBy.accessibilityId("Add")).click();
				Thread.sleep(1000);
				driver.findElement(AppiumBy.accessibilityId("Add Part")).click();
				driver.findElement(AppiumBy.accessibilityId("switchView")).click();
				Thread.sleep(4000); 
				driver.findElement(AppiumBy.accessibilityId("Material, None, ")).click();
				Thread.sleep(2000); 
				driver.findElement(By.xpath("//XCUIElementTypeStaticText[contains(@name,'Available')]")).click();
				Thread.sleep(3000);
				driver.findElement(AppiumBy.accessibilityId("UOM, None, ")).click();			//for iPhone11
				Thread.sleep(2000);
				driver.findElement(AppiumBy.accessibilityId("EA")).click();				//for iPhone11	
				Thread.sleep(2000);
				driver.findElement(AppiumBy.accessibilityId("Quantity, Value")).sendKeys("1");
				driver.findElement(By.xpath("(//XCUIElementTypeButton[@name='Done'])[1]")).click();
				logger.info("Part Added to Work Order");
				Thread.sleep(2000);
				driver.findElement(By.xpath("//XCUIElementTypeButton[contains(@name,'Work Orders')]")).click();
			}
			catch (Exception e) {
				logger.info("Error while AddPart");
				logger.info(e.getMessage());
				e.printStackTrace();
				return;
			}
		}
		public void IssuePartAddedToWorkOrder() throws Exception{
			logger.info("Inside IssuePartAddedToWorkOrder method");
			try {
				driver.findElement(By.xpath("//XCUIElementTypeStaticText[contains(@name,'Received')]")).click();
				JavascriptExecutor js = (JavascriptExecutor) driver;
				js.executeScript("mobile:scroll", ImmutableMap.of("direction", "down","distance", "2"));
				driver.findElement(By.xpath("//XCUIElementTypeStaticText[@label='keyName is Parts']")).click();
				driver.findElement(By.xpath("//XCUIElementTypeStaticText[contains(@name,'0 of 1 EA')]")).click();
				driver.findElement(AppiumBy.accessibilityId("Add")).click();
				driver.findElement(AppiumBy.accessibilityId("Issue Part")).click();
				driver.findElement(AppiumBy.accessibilityId("Done")).click();
				driver.findElement(By.xpath("//XCUIElementTypeButton[contains(@name,'Parts')]")).click();
				driver.findElement(By.xpath("//XCUIElementTypeButton[contains(@name,'Work Order')]")).click();
				Thread.sleep(1000);
				driver.findElement(By.xpath("//XCUIElementTypeButton[contains(@name,'Work Orders')]")).click();
			}
			catch (Exception e) {
				logger.info("Error while AddPart");
				logger.info(e.getMessage());
				e.printStackTrace();
				return;
			}
		}
		public void startWorkOrder()throws Exception {
			logger.info("Inside StartWorkOrder method");
			try {
				driver.findElement(By.xpath("//XCUIElementTypeStaticText[contains(@name,'Received')]")).click();
				driver.findElement(AppiumBy.accessibilityId("Clock In")).click();
				WebDriverWait waitForElement = new WebDriverWait(driver, Duration.ofSeconds(10));
				waitForElement.until(ExpectedConditions.visibilityOfElementLocated(AppiumBy.accessibilityId("Toast Message Work Order Started")));
				Thread.sleep(5000);
				logger.info("Work Order Started");
				driver.findElement(By.xpath("//XCUIElementTypeButton[contains(@name,'Work Orders')]")).click();
			}
			catch (Exception e) {
				logger.info("Error while StartWorkOrder");
				logger.info(e.getMessage());
				e.printStackTrace();
				return;
			}
		}
		
		public void resultRecordingForWorkOrder()throws Exception{
			logger.info("Inside resultRecordingForWorkOrder method");
			try {
				driver.findElement(By.xpath("//XCUIElementTypeStaticText[contains(@name,'Started')]")).click();
				JavascriptExecutor js = (JavascriptExecutor) driver;
				js.executeScript("mobile:scroll", ImmutableMap.of("direction", "down"));
				WebElement eleInspectionLot=driver.findElement(AppiumBy.accessibilityId("Inspection Lot"));
		        //while (!eleInspectionLot.isDisplayed()) {
		        //    scroll(driver);
		        //}
		        Point location = eleInspectionLot.getLocation();
		        Dimension size = eleInspectionLot.getSize();
		        // Calculate the coordinates to click below the element
		        int clickX = location.getX() + size.getWidth() / 2; // Center X of the element
		        int clickY = location.getY() + size.getHeight() + 10; // 10 pixels below the element

		        // Perform the click action at the calculated coordinates
		        TouchAction touchAction = new TouchAction((PerformsTouchActions) driver);
		        touchAction.tap(PointOption.point(clickX, clickY)).perform();
		        logger.info("Inspection Lot Opened");
		        //Result Recording Started
		        driver.findElement(AppiumBy.accessibilityId("Record Results")).click();
		        driver.findElement(AppiumBy.accessibilityId("Diameter, Value")).sendKeys("70");
		        driver.findElement(By.xpath("//XCUIElementTypeStaticText[@name='Validate']")).click();
		        WebElement valuation=driver.findElement(AppiumBy.accessibilityId("Valuation, Accepted, "));
		        if(valuation.isDisplayed()) {
		        	logger.info("Valuation is Accepted");
		        }
		        else {
		        	logger.info("Issue while Valuation");
		        }
		        driver.findElement(AppiumBy.accessibilityId("Done")).click();
		        driver.findElement(AppiumBy.accessibilityId("Proposal Valuation, None, ")).click();
		        driver.findElement(AppiumBy.accessibilityId("Can be used")).click();
		        driver.findElement(AppiumBy.accessibilityId("Done")).click();
		        //Set Usage Decision
		        driver.findElement(AppiumBy.accessibilityId("Code, None, ")).click();
		        driver.findElement(AppiumBy.accessibilityId("Can be used")).click();
		        driver.findElement(AppiumBy.accessibilityId("Done")).click();
				driver.findElement(By.xpath("//XCUIElementTypeButton[contains(@name,'Work Order')]")).click();
				Thread.sleep(1000);
				driver.findElement(By.xpath("//XCUIElementTypeButton[contains(@name,'Work Orders')]")).click();
				logger.info("Result Recording Successful");
			}
			catch (Exception e) {
				logger.info("Error while resultRecordingForWorkOrder");
				logger.info(e.getMessage());
				e.printStackTrace();
				return;
			}
			
		}
		public void operationConfirmation()throws Exception{
			logger.info("Inside operationConfirmation method");
			logger.info("Work Order should already be started");
			//Make sure that Work Order is already started
			try {
				driver.findElement(By.xpath("//XCUIElementTypeStaticText[contains(@name,'Started')]")).click();
				JavascriptExecutor js = (JavascriptExecutor) driver;
				js.executeScript("mobile:scroll", ImmutableMap.of("direction", "down"));
				driver.findElement(By.xpath("//XCUIElementTypeStaticText[contains(@name,'0010')]")).click();
				logger.info("Operation Confirmation - Inprogress");
				driver.findElement(AppiumBy.accessibilityId("Confirm")).click();
				driver.findElement(AppiumBy.accessibilityId("OK")).click();
				driver.findElement(AppiumBy.accessibilityId("Activity Type, None, ")).click();
				driver.findElement(AppiumBy.accessibilityId("MAINTT - Maintenance EAM")).click();
				driver.findElement(AppiumBy.accessibilityId("Done")).click();
				Thread.sleep(2000);
				WebElement isConfirmaed=driver.findElement(AppiumBy.accessibilityId("Unconfirm"));
				if(isConfirmaed.isDisplayed()) {
					logger.info("Operation is Confirmed Successfully");
				}
				else {
					logger.info("Issue in Operation Confirmation");
				}
				driver.findElement(By.xpath("//XCUIElementTypeButton[contains(@name,'Work Order')]")).click();
				Thread.sleep(1000);
				driver.findElement(By.xpath("//XCUIElementTypeButton[contains(@name,'Work Orders')]")).click();
			}
			catch (Exception e) {
				logger.info("Error while operationConfirmation");
				logger.info(e.getMessage());
				e.printStackTrace();
				return;
			}
		}

		public void WorkOrderComplete()throws Exception{
			logger.info("Inside WorkOrderComplete method");
			try {
				driver.findElement(By.xpath("//XCUIElementTypeStaticText[contains(@name,'Started')]")).click();
				driver.findElement(AppiumBy.accessibilityId("Complete")).click();
				driver.findElement(By.xpath("(//XCUIElementTypeButton[@name='Complete'])[2]")).click();
				logger.info("Work Order Completed");
				driver.findElement(By.xpath("//XCUIElementTypeButton[contains(@name,'Work Orders')]")).click();
				Thread.sleep(3000);
			}
			catch (Exception e) {
				logger.info("Error while WorkOrderComplete");
				logger.info(e.getMessage());
				e.printStackTrace();
				return;
			}
		}

		
//	    	//Enter email-id
//			driver.findElement(By.xpath("//XCUIElementTypeApplication[1]/XCUIElementTypeWindow[1]/XCUIElementTypeOther[1]/XCUIElementTypeTextField[1]")).sendKeys("test@testname.com");
//			
//			//Enter Password		
//			driver.findElement(By.xpath("//XCUIElementTypeApplication[1]/XCUIElementTypeWindow[1]/XCUIElementTypeOther[1]/XCUIElementTypeSecureTextField[1]")).sendKeys("testmunk");
//					
//			//Click on login button	
//			driver.findElement(By.xpath("//XCUIElementTypeApplication[1]/XCUIElementTypeWindow[1]/XCUIElementTypeOther[1]/XCUIElementTypeButton[1]")).click();
//	    	
//	    	
////			Thread.sleep(5000);
////			verifyTextOnElement(gotItButton, "GOT IT","Got It Button");
//////			gotItButton.click();
//////			Thread.sleep(5000);
////			clickElement(gotItButton, "gotItButton");
//////			logger.info("Clicked on Got It Button");
////			clickElement(addotherEmail, "addotherEmail Option");
//////			logger.info("Clicked on Add Other Email option");
//
//		} catch (Exception e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//			return;
//		}
	   
		//driver.get("https://google.com");
		//driver.findElement(By.id("com.android.chrome:id/url_bar")).sendKeys(("Automation"));
		//driver.findElement(By.id("com.android.chrome:id/url_bar")).sendKeys(Keys.ENTER);
	    //clickElement(animationBy, "animationBy");
//		clickElement(ButtonImage, "ButtonImage");


	
////	public AndroidDriver<WebElement> driver2;
////	public static AppiumDriver driver;
////	public WebDriver driver1;
////	public ExtentTest test;
////	@AndroidFindBy(id="com.android.camera:id/v9_thumbnail_image") public WebElement ButtonImage;
//	
////	@FindBy(id = "welcome_tour_got_it")
////	public WebElement gotItButton;
////	
////	@FindBy(id = "setup_addresses_add_another")
////	WebElement addotherEmail;
////	
////	@FindBy(id = "(//*[@id='account_setup_item'])[1]")
////	WebElement accountSetupOption;
////	
////	@FindBy(id = "identifierId")
////	WebElement emailEnterTxtBox;
////	
////	@FindBy(xpath = "(//*[@class='android.widget.Button'])[3]")
////	WebElement nextButton;
////	
////	@FindBy(xpath = "(//*[@class='android.widget.TextView'])[1]")
////	public WebElement apiDemoTitle;
//	
//	
//	
//	public SamplePage (AppiumDriver driver,ExtentTest test) {
//		this.driver = driver;
//		this.test = test;
//        PageFactory.initElements(driver, this);
//	}
//	
//	public Logger logger = Logger.getLogger(SamplePage.class);
//
//	public void sampleMethod() throws Exception {
//		logger.info("Inside sample method");
////	    try {
////	    	//Enter email-id
////			driver.findElement(By.xpath("//XCUIElementTypeApplication[1]/XCUIElementTypeWindow[1]/XCUIElementTypeOther[1]/XCUIElementTypeTextField[1]")).sendKeys("test@testname.com");
////			
////			//Enter Password		
////			driver.findElement(By.xpath("//XCUIElementTypeApplication[1]/XCUIElementTypeWindow[1]/XCUIElementTypeOther[1]/XCUIElementTypeSecureTextField[1]")).sendKeys("testmunk");
////					
////			//Click on login button	
////			driver.findElement(By.xpath("//XCUIElementTypeApplication[1]/XCUIElementTypeWindow[1]/XCUIElementTypeOther[1]/XCUIElementTypeButton[1]")).click();
////	    	
////	    	
//////			Thread.sleep(5000);
//////			verifyTextOnElement(gotItButton, "GOT IT","Got It Button");
////////			gotItButton.click();
////////			Thread.sleep(5000);
//////			clickElement(gotItButton, "gotItButton");
////////			logger.info("Clicked on Got It Button");
//////			clickElement(addotherEmail, "addotherEmail Option");
////////			logger.info("Clicked on Add Other Email option");
////
////		} catch (Exception e) {
////			// TODO Auto-generated catch block
////			e.printStackTrace();
////			return;
////		}
//	   
//		//driver.get("https://google.com");
//		//driver.findElement(By.id("com.android.chrome:id/url_bar")).sendKeys(("Automation"));
//		//driver.findElement(By.id("com.android.chrome:id/url_bar")).sendKeys(Keys.ENTER);
//	    //clickElement(animationBy, "animationBy");
////		clickElement(ButtonImage, "ButtonImage");
//
//	}

}
